# FAQ - Perguntas Frequentes

**Versão:** 1.0.0  
**Autor:** Manus AI  
**Data:** Dezembro 2024  

## Perguntas Gerais

### O que é o Email Assistant?

O Email Assistant é um aplicativo Android inovador que permite gerenciar seus e-mails do Microsoft Outlook usando apenas comandos de voz. Desenvolvido especificamente para uso durante o trânsito, o aplicativo oferece análise inteligente de e-mails, resumos conversacionais, e capacidade de responder, arquivar ou excluir mensagens sem tocar no dispositivo.

### Quais dispositivos são compatíveis?

O aplicativo é compatível com dispositivos Android 7.0 (API 24) ou superior, com pelo menos 2GB de RAM e 500MB de espaço livre. A maioria dos smartphones Android lançados após 2017 atendem a estes requisitos. O dispositivo deve ter microfone funcional e conexão com internet.

### O aplicativo é gratuito?

O aplicativo em si é gratuito, mas requer chaves de API do OpenAI e Microsoft Graph para funcionar. A API do OpenAI tem custos baseados em uso, tipicamente muito baixos para uso pessoal normal. A API do Microsoft Graph é gratuita para contas pessoais do Outlook.

### É seguro usar durante a condução?

Sim, o aplicativo foi especificamente projetado para uso hands-free seguro durante a condução. O modo hands-free permite interação completa por voz, eliminando a necessidade de tocar na tela. Sempre mantenha atenção na estrada e siga as leis de trânsito locais.

## Instalação e Configuração

### Como obtenho as chaves de API necessárias?

Para OpenAI: visite openai.com, crie uma conta, vá para API Keys e gere uma nova chave. Para Microsoft Graph: registre o aplicativo no portal do Azure (portal.azure.com) em Azure Active Directory > App registrations. Guias detalhados estão disponíveis na documentação de instalação.

### Por que preciso configurar APIs externas?

As APIs externas fornecem funcionalidades essenciais: OpenAI para análise inteligente de e-mails e Microsoft Graph para acesso seguro aos seus e-mails do Outlook. Esta arquitetura garante que o aplicativo tenha acesso às tecnologias mais avançadas disponíveis.

### O aplicativo funciona com contas corporativas?

Sim, o aplicativo suporta contas corporativas do Office 365. No entanto, pode ser necessário aprovação do administrador de TI para as permissões necessárias. Consulte seu departamento de TI se encontrar problemas de autenticação com contas corporativas.

### Posso usar múltiplas contas de e-mail?

Atualmente, o aplicativo suporta uma conta Microsoft por instalação. Para usar múltiplas contas, você precisaria reconfigurar o aplicativo ou usar múltiplos dispositivos. Suporte para múltiplas contas está planejado para versões futuras.

## Funcionalidades

### Quais comandos de voz são suportados?

O aplicativo suporta uma ampla gama de comandos em português brasileiro, incluindo:
- Análise: "Analisar e-mails dos últimos 3 dias"
- Busca: "Buscar e-mails sobre reunião"
- Gerenciamento: "Arquivar este e-mail", "Excluir e-mail do João"
- Composição: "Enviar e-mail para Maria sobre projeto"
- Correlação: "Mostrar e-mails similares a este"

### Como funciona a análise de e-mails similares?

O sistema utiliza embeddings vetoriais gerados por IA para analisar o conteúdo semântico dos e-mails. Isso permite identificar mensagens relacionadas mesmo quando não compartilham palavras-chave óbvias, baseando-se no significado e contexto do conteúdo.

### O aplicativo funciona offline?

Funcionalidades básicas como visualização de e-mails em cache funcionam offline, mas análise de IA, sincronização de novos e-mails, e envio de mensagens requerem conexão com internet. O aplicativo otimiza o uso de dados através de cache inteligente.

### Posso personalizar os comandos de voz?

O sistema de reconhecimento aceita variações naturais dos comandos, mas comandos específicos não são personalizáveis na versão atual. O aplicativo compreende sinônimos e diferentes formas de expressar a mesma intenção.

## Problemas Técnicos

### O reconhecimento de voz não está funcionando bem

Verifique se as permissões de microfone foram concedidas, teste o microfone em outros aplicativos, certifique-se de que está falando claramente e em ambiente não muito ruidoso. Ajuste as configurações de sensibilidade nas configurações do aplicativo.

### Recebo erros de autenticação

Verifique se o Client ID do Azure foi inserido corretamente, confirme que as permissões foram configuradas no Azure Active Directory, e tente fazer logout e login novamente. Para contas corporativas, consulte o administrador de TI.

### A análise de IA está muito lenta

A velocidade depende da conexão com internet e do volume de e-mails sendo analisados. Verifique sua conectividade, considere analisar períodos menores de tempo, e certifique-se de que sua conta OpenAI tem créditos suficientes.

### O aplicativo consome muita bateria

O uso contínuo de microfone e processamento de IA pode consumir bateria. Use o modo hands-free apenas quando necessário, ajuste configurações de análise automática, e considere usar carregador veicular durante uso prolongado.

## Segurança e Privacidade

### Meus e-mails são armazenados nos servidores do aplicativo?

Não, o aplicativo não possui servidores próprios. E-mails são acessados diretamente do Microsoft Graph e processados localmente ou através das APIs configuradas (OpenAI). Nenhum dado é armazenado em servidores de terceiros além dos serviços que você configurou.

### As chaves de API são seguras?

Sim, todas as chaves de API são criptografadas usando AES-256 e armazenadas no Android Keystore quando disponível. As chaves nunca são transmitidas em texto claro e são protegidas por múltiplas camadas de segurança.

### Posso revogar o acesso do aplicativo?

Sim, você pode revogar o acesso a qualquer momento através das configurações de segurança da sua conta Microsoft. Vá para account.microsoft.com > Segurança > Aplicativos e serviços conectados, e remova o Email Assistant da lista.

### O aplicativo coleta dados pessoais?

O aplicativo coleta apenas dados necessários para funcionalidade (e-mails para análise, configurações de usuário). Não há coleta de dados para fins publicitários ou comerciais. Consulte a política de privacidade para detalhes completos.

## Suporte e Atualizações

### Como obtenho suporte técnico?

Consulte primeiro esta FAQ e a documentação completa. Para problemas não resolvidos, entre em contato através do e-mail de suporte ou abra uma issue no repositório do projeto no GitHub.

### Com que frequência o aplicativo é atualizado?

Atualizações são lançadas conforme necessário para correções de bugs, melhorias de segurança, e novas funcionalidades. Atualizações importantes são comunicadas através dos canais oficiais do projeto.

### Posso contribuir para o desenvolvimento?

Sim! O projeto é open source e aceita contribuições. Consulte o guia de contribuição no repositório para informações sobre como participar do desenvolvimento.

### Há planos para versão iOS?

Uma versão iOS está sendo considerada para o futuro, mas não há cronograma definido. O foco atual está em aperfeiçoar a versão Android e adicionar funcionalidades solicitadas pelos usuários.

## Resolução de Problemas Comuns

### "Erro de conexão com Microsoft Graph"

1. Verifique sua conexão com internet
2. Confirme que o Client ID está correto
3. Verifique se as permissões foram configuradas no Azure
4. Tente fazer logout e login novamente
5. Para contas corporativas, consulte o administrador de TI

### "Chave de API OpenAI inválida"

1. Verifique se a chave foi copiada completamente
2. Confirme que a chave não expirou
3. Verifique se há créditos suficientes na conta OpenAI
4. Gere uma nova chave se necessário

### "Microfone não detectado"

1. Verifique as permissões de microfone nas configurações do Android
2. Teste o microfone em outros aplicativos
3. Reinicie o aplicativo
4. Reinicie o dispositivo se necessário

### "Aplicativo trava ou fecha inesperadamente"

1. Verifique se há atualizações disponíveis
2. Limpe o cache do aplicativo
3. Reinicie o dispositivo
4. Reinstale o aplicativo se o problema persistir

Para problemas não listados aqui, consulte a documentação completa ou entre em contato com o suporte técnico.

