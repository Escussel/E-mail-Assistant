# 🚀 Guia de Build Online - Email Assistant

**Versão:** 1.0.0  
**Autor:** Manus AI  
**Data:** Dezembro 2024  

## Índice

1. [Visão Geral](#visão-geral)
2. [Configuração do Repositório GitHub](#configuração-do-repositório-github)
3. [Configuração de Secrets](#configuração-de-secrets)
4. [Geração de Keystore](#geração-de-keystore)
5. [Processo de Build Automatizado](#processo-de-build-automatizado)
6. [Criação de Releases](#criação-de-releases)
7. [Download do APK](#download-do-apk)
8. [Solução de Problemas](#solução-de-problemas)

## Visão Geral

O Email Assistant está configurado com um sistema completo de build online usando GitHub Actions. Este sistema permite:

- **Build automático** do APK a cada push ou pull request
- **Assinatura digital** automática para releases
- **Distribuição automatizada** através de GitHub Releases
- **Testes de qualidade** e verificações de segurança
- **Versionamento automático** e geração de changelogs

### Benefícios do Build Online

O sistema de build online oferece várias vantagens sobre a compilação local:

**Consistência**: Todos os builds são realizados em ambiente controlado e idêntico, eliminando problemas de "funciona na minha máquina". O ambiente de build é sempre limpo e atualizado, garantindo reprodutibilidade.

**Automação**: O processo é completamente automatizado, desde a detecção de mudanças no código até a disponibilização do APK para download. Não há necessidade de intervenção manual para builds de rotina.

**Segurança**: As chaves de assinatura são armazenadas de forma segura como secrets do GitHub, nunca expostas no código ou logs. O processo de assinatura acontece em ambiente isolado e seguro.

**Rastreabilidade**: Cada build é associado a um commit específico, permitindo rastrear exatamente qual código gerou cada APK. Logs completos de build são mantidos para auditoria e debugging.

**Distribuição**: APKs são automaticamente disponibilizados através de GitHub Releases, com links diretos para download e informações detalhadas sobre cada versão.

## Configuração do Repositório GitHub

### Criando o Repositório

Para configurar o build online, você precisa primeiro criar um repositório no GitHub e fazer upload do código do Email Assistant.

**Passo 1: Criar Repositório**
1. Acesse [GitHub.com](https://github.com) e faça login
2. Clique em "New repository" ou acesse [github.com/new](https://github.com/new)
3. Configure o repositório:
   - **Nome**: `email-assistant` (ou nome de sua preferência)
   - **Descrição**: "Aplicativo Android para análise inteligente de e-mails por voz"
   - **Visibilidade**: Public (recomendado) ou Private
   - **Initialize**: Não marque nenhuma opção (vamos fazer upload do código existente)

**Passo 2: Upload do Código**
```bash
# No diretório do projeto Email Assistant
git remote add origin https://github.com/SEU_USUARIO/email-assistant.git
git branch -M main
git push -u origin main
```

**Passo 3: Verificar Upload**
Após o upload, verifique se todos os arquivos estão presentes no repositório:
- Código fonte em `app/src/`
- Workflows em `.github/workflows/`
- Scripts em `scripts/`
- Documentação em `docs/`

### Configuração de Permissões

O repositório precisa de permissões específicas para o GitHub Actions funcionar corretamente:

1. Vá para **Settings** > **Actions** > **General**
2. Em "Actions permissions", selecione "Allow all actions and reusable workflows"
3. Em "Workflow permissions", selecione "Read and write permissions"
4. Marque "Allow GitHub Actions to create and approve pull requests"

Essas permissões são necessárias para que os workflows possam:
- Fazer build do código
- Criar releases automaticamente
- Fazer upload de artifacts
- Atualizar o repositório com tags de versão

## Configuração de Secrets

Os secrets do GitHub são usados para armazenar informações sensíveis como chaves de assinatura. Eles são criptografados e só acessíveis durante a execução dos workflows.

### Secrets Necessários

Para o build completo funcionar, você precisa configurar os seguintes secrets:

| Secret | Descrição | Obrigatório |
|--------|-----------|-------------|
| `KEYSTORE_BASE64` | Keystore codificado em base64 | ✅ Para releases |
| `KEYSTORE_PASSWORD` | Senha do keystore | ✅ Para releases |
| `KEY_ALIAS` | Alias da chave no keystore | ✅ Para releases |
| `KEY_PASSWORD` | Senha da chave específica | ✅ Para releases |

### Como Adicionar Secrets

1. No repositório GitHub, vá para **Settings** > **Secrets and variables** > **Actions**
2. Clique em **New repository secret**
3. Adicione cada secret individualmente:
   - **Name**: Nome exato do secret (ex: `KEYSTORE_BASE64`)
   - **Secret**: Valor do secret (será mascarado automaticamente)
4. Clique em **Add secret**

**Importante**: Os secrets são case-sensitive e devem ser digitados exatamente como mostrado na tabela acima.

### Verificação de Secrets

Após adicionar todos os secrets, você deve ver uma lista similar a esta na página de secrets:

```
KEYSTORE_BASE64     Updated X minutes ago
KEYSTORE_PASSWORD   Updated X minutes ago  
KEY_ALIAS          Updated X minutes ago
KEY_PASSWORD       Updated X minutes ago
```

Se algum secret estiver faltando, os workflows de release falharão com erro de "secret not found".



## Geração de Keystore

O keystore é necessário para assinar digitalmente o APK, garantindo sua autenticidade e integridade. Sem assinatura, o Android não permitirá a instalação do aplicativo.

### Usando o Script Automatizado

O projeto inclui um script que automatiza completamente a geração do keystore:

```bash
# No diretório do projeto
cd scripts
./generate-keystore.sh
```

O script irá:
1. Solicitar informações da organização (nome, cidade, estado, país)
2. Gerar senhas seguras automaticamente
3. Criar o keystore com configurações otimizadas
4. Gerar arquivo com secrets para GitHub
5. Criar arquivo de propriedades para build local

### Geração Manual (Alternativa)

Se preferir gerar manualmente, use os comandos abaixo:

```bash
# Gerar keystore
keytool -genkey -v \
    -keystore app/emailassistant-release.jks \
    -alias emailassistant \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass SUA_SENHA_KEYSTORE \
    -keypass SUA_SENHA_CHAVE \
    -dname "CN=Email Assistant Team, OU=Manus AI, O=Manus AI, L=São Paulo, S=SP, C=BR"

# Converter para base64
base64 -w 0 app/emailassistant-release.jks > keystore-base64.txt
```

### Informações do Keystore

Após a geração, você terá:

**Arquivos Criados:**
- `app/emailassistant-release.jks` - O keystore propriamente dito
- `keystore.properties` - Propriedades para build local
- `github-secrets.txt` - Secrets para configurar no GitHub

**Informações Importantes:**
- **Validade**: 10.000 dias (~27 anos)
- **Algoritmo**: RSA 2048 bits
- **Formato**: JKS (Java KeyStore)

### Segurança do Keystore

**⚠️ CRÍTICO**: O keystore é a chave mestra do seu aplicativo. Sem ele, você não conseguirá atualizar o app na Google Play Store.

**Medidas de Segurança:**
1. **Backup**: Faça múltiplas cópias em locais seguros
2. **Senhas**: Use senhas fortes e únicas
3. **Acesso**: Limite o acesso apenas a pessoas autorizadas
4. **Versionamento**: NUNCA commite o keystore no Git
5. **Criptografia**: Mantenha backups criptografados

**Locais Recomendados para Backup:**
- Cofre digital corporativo
- Serviço de nuvem criptografado
- Dispositivo físico offline
- Documentação impressa (apenas para emergências)

## Processo de Build Automatizado

O sistema de build é acionado automaticamente em várias situações e executa diferentes tipos de build dependendo do contexto.

### Triggers de Build

O build automático é acionado nos seguintes casos:

**Push para Branch Principal:**
```yaml
on:
  push:
    branches: [ main, develop ]
```
- Executa build de debug
- Roda testes automatizados
- Verifica qualidade do código
- Gera APK de desenvolvimento

**Pull Requests:**
```yaml
on:
  pull_request:
    branches: [ main ]
```
- Valida mudanças propostas
- Executa testes completos
- Verifica se o build não quebrou
- Gera relatórios de qualidade

**Tags de Release:**
```yaml
on:
  push:
    tags: [ 'v*' ]
```
- Executa build de release
- Assina o APK automaticamente
- Cria release no GitHub
- Disponibiliza APK para download

**Execução Manual:**
```yaml
on:
  workflow_dispatch:
```
- Permite executar build manualmente
- Útil para testes e debugging
- Pode escolher tipo de build (debug/release)

### Etapas do Build

Cada build passa pelas seguintes etapas:

**1. Preparação do Ambiente**
- Checkout do código fonte
- Configuração do JDK 17
- Setup do Android SDK
- Cache de dependências Gradle

**2. Configuração de Assinatura** (apenas para releases)
- Decodificação do keystore
- Configuração de propriedades de assinatura
- Validação de secrets

**3. Compilação**
- Download de dependências
- Compilação do código Kotlin
- Processamento de recursos
- Geração do APK

**4. Testes e Qualidade**
- Execução de testes unitários
- Análise de lint
- Verificações de segurança
- Geração de relatórios

**5. Assinatura** (apenas para releases)
- Assinatura digital do APK
- Alinhamento ZIP
- Otimização final

**6. Distribuição**
- Upload de artifacts
- Criação de release (se aplicável)
- Geração de notas de release
- Notificações de status

### Tipos de Build

**Debug Build:**
- Não requer assinatura
- Inclui informações de debug
- Permite debugging via ADB
- Sufixo `.debug` no package name
- Disponível como artifact por 30 dias

**Release Build:**
- Requer keystore e assinatura
- Código otimizado e ofuscado
- Pronto para distribuição
- Disponível como GitHub Release
- Mantido permanentemente

### Monitoramento do Build

Você pode acompanhar o progresso do build em tempo real:

1. Vá para a aba **Actions** do repositório
2. Clique no workflow em execução
3. Acompanhe cada etapa em tempo real
4. Veja logs detalhados de cada step

**Indicadores de Status:**
- 🟡 **Amarelo**: Build em execução
- ✅ **Verde**: Build bem-sucedido
- ❌ **Vermelho**: Build falhou
- ⚪ **Cinza**: Build cancelado ou pendente

## Criação de Releases

O sistema de releases automatiza completamente o processo de versionamento e distribuição do aplicativo.

### Usando o Script de Release

O método mais simples é usar o script automatizado:

```bash
# No diretório do projeto
./scripts/create-release.sh
```

O script irá:
1. Verificar o estado do repositório
2. Solicitar o tipo de release (patch/minor/major)
3. Atualizar automaticamente os números de versão
4. Criar commit com as mudanças
5. Criar e enviar tag de release
6. Acionar build automático

### Tipos de Release

**Patch Release (1.0.0 → 1.0.1):**
- Correções de bugs
- Melhorias de performance
- Atualizações de segurança
- Não introduz novas funcionalidades

**Minor Release (1.0.0 → 1.1.0):**
- Novas funcionalidades
- Melhorias na interface
- Novos recursos opcionais
- Mantém compatibilidade

**Major Release (1.0.0 → 2.0.0):**
- Mudanças significativas na arquitetura
- Quebra de compatibilidade
- Redesign completo
- Novas funcionalidades principais

### Release Manual

Se preferir controle total sobre o processo:

```bash
# 1. Atualizar versão no build.gradle
# versionName "1.1.0"
# versionCode 2

# 2. Commit das mudanças
git add app/build.gradle
git commit -m "chore: bump version to 1.1.0"

# 3. Criar tag
git tag -a "v1.1.0" -m "Release 1.1.0 - Novas funcionalidades de IA"

# 4. Enviar para GitHub
git push origin main
git push origin v1.1.0
```

### Conteúdo do Release

Cada release automaticamente inclui:

**APK Assinado:**
- Arquivo principal para instalação
- Assinado digitalmente
- Otimizado para produção

**Notas de Release:**
- Lista de funcionalidades
- Requisitos do sistema
- Instruções de instalação
- Links para documentação

**Artifacts Adicionais:**
- Mapping files (para debugging)
- Relatórios de build
- Informações de commit

**Metadados:**
- Data e hora do build
- Commit SHA associado
- Informações do ambiente de build
- Checksums para verificação

## Download do APK

Após um release bem-sucedido, o APK estará disponível para download através de várias formas.

### GitHub Releases (Recomendado)

**Acesso Direto:**
1. Vá para a página do repositório no GitHub
2. Clique na aba **Releases** (ou acesse `/releases`)
3. Encontre a versão desejada
4. Clique no arquivo APK para download

**URL Direto:**
```
https://github.com/SEU_USUARIO/email-assistant/releases/latest/download/EmailAssistant-release-signed.apk
```

### GitHub Actions Artifacts

Para builds de desenvolvimento (debug):

1. Vá para **Actions** > **Build específico**
2. Role até a seção **Artifacts**
3. Clique em **EmailAssistant-Debug-APK**
4. Faça download do arquivo ZIP

**Nota**: Artifacts têm prazo de validade (30 dias para debug, 90 dias para release).

### API do GitHub

Para automação ou integração:

```bash
# Obter informações do último release
curl -s https://api.github.com/repos/SEU_USUARIO/email-assistant/releases/latest

# Download direto do APK
curl -L -o EmailAssistant.apk \
  $(curl -s https://api.github.com/repos/SEU_USUARIO/email-assistant/releases/latest | \
    grep "browser_download_url.*\.apk" | cut -d '"' -f 4)
```

### Verificação de Integridade

Sempre verifique a integridade do APK baixado:

**Verificar Assinatura:**
```bash
# Usando aapt (Android Asset Packaging Tool)
aapt dump badging EmailAssistant.apk | grep "package:"

# Verificar certificado
jarsigner -verify -verbose -certs EmailAssistant.apk
```

**Verificar Checksum:**
```bash
# SHA256
sha256sum EmailAssistant.apk

# Compare com o valor fornecido no release
```

### Instalação do APK

**Pré-requisitos:**
- Android 7.0+ (API 24)
- 2GB RAM mínimo
- 100MB espaço livre
- Fontes desconhecidas habilitadas

**Passos de Instalação:**
1. Baixe o APK do GitHub Releases
2. No Android, vá para **Configurações** > **Segurança**
3. Habilite **Fontes desconhecidas** ou **Instalar apps desconhecidos**
4. Abra o arquivo APK baixado
5. Toque em **Instalar**
6. Aguarde a instalação concluir
7. Toque em **Abrir** para iniciar o app

**Primeira Execução:**
- O app solicitará permissões necessárias
- Configure sua conta Microsoft Outlook
- Adicione sua chave API do OpenAI
- Teste os comandos de voz básicos

## Solução de Problemas

Esta seção cobre os problemas mais comuns e suas soluções.

### Problemas de Build

**Erro: "Keystore not found"**
```
Causa: Secrets não configurados corretamente
Solução: 
1. Verifique se todos os 4 secrets estão configurados
2. Confirme que os nomes estão corretos (case-sensitive)
3. Regenere o keystore se necessário
```

**Erro: "Gradle build failed"**
```
Causa: Dependências ou configuração incorreta
Solução:
1. Verifique logs detalhados no GitHub Actions
2. Confirme que build.gradle está correto
3. Limpe cache: Delete .gradle e rebuild
```

**Erro: "Tests failed"**
```
Causa: Testes unitários falhando
Solução:
1. Execute testes localmente primeiro
2. Corrija falhas antes de fazer push
3. Use continue-on-error para testes não críticos
```

### Problemas de Release

**Release não criado automaticamente**
```
Causa: Tag não segue padrão v*
Solução:
1. Use formato v1.0.0, v1.1.0, etc.
2. Verifique se tag foi enviada: git push origin --tags
3. Confirme que workflow está habilitado
```

**APK não assinado**
```
Causa: Secrets de keystore incorretos
Solução:
1. Regenere keystore com script
2. Atualize todos os secrets no GitHub
3. Teste com build manual primeiro
```

### Problemas de Download

**APK não encontrado**
```
Causa: Build falhou ou ainda em execução
Solução:
1. Verifique status do build em Actions
2. Aguarde conclusão do workflow
3. Verifique se release foi criado
```

**Erro de instalação no Android**
```
Causa: APK corrompido ou incompatível
Solução:
1. Baixe novamente o APK
2. Verifique checksum
3. Confirme compatibilidade (Android 7.0+)
4. Habilite fontes desconhecidas
```

### Logs e Debugging

**Acessar Logs Detalhados:**
1. GitHub Actions > Workflow específico
2. Clique em cada step para ver logs
3. Use "Download logs" para análise offline

**Debugging Local:**
```bash
# Simular build localmente
./gradlew assembleDebug --stacktrace --info

# Verificar dependências
./gradlew dependencies

# Limpar projeto
./gradlew clean
```

**Contato para Suporte:**
- Abra issue no repositório GitHub
- Inclua logs relevantes
- Descreva passos para reproduzir
- Mencione versão do Android e dispositivo

---

**Desenvolvido com ❤️ e excelência técnica por Manus AI**

*Este guia garante que você tenha acesso fácil e automatizado ao APK do Email Assistant, sempre atualizado e pronto para uso.*

