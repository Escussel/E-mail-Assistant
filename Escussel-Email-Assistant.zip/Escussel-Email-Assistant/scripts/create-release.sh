#!/bin/bash

# Script para criar release do Email Assistant
# Manus AI

set -e

echo "🚀 Criando Release do Email Assistant"
echo "====================================="

# Verificar se estamos em um repositório git
if [ ! -d ".git" ]; then
    echo "❌ Erro: Este não é um repositório Git"
    exit 1
fi

# Verificar se há mudanças não commitadas
if [ -n "$(git status --porcelain)" ]; then
    echo "⚠️  Há mudanças não commitadas. Deseja continuar? (y/N)"
    read -r response
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "❌ Release cancelado"
        exit 1
    fi
fi

# Obter versão atual
CURRENT_VERSION=$(grep 'versionName' app/build.gradle | sed 's/.*"\(.*\)".*/\1/')
echo "📋 Versão atual: $CURRENT_VERSION"

# Solicitar nova versão
echo ""
echo "Tipos de release:"
echo "  1. Patch (1.0.0 -> 1.0.1) - Correções de bugs"
echo "  2. Minor (1.0.0 -> 1.1.0) - Novas funcionalidades"
echo "  3. Major (1.0.0 -> 2.0.0) - Mudanças significativas"
echo "  4. Custom - Especificar versão manualmente"
echo ""

read -p "Escolha o tipo de release [1-4]: " RELEASE_TYPE

case $RELEASE_TYPE in
    1)
        # Patch version
        NEW_VERSION=$(echo $CURRENT_VERSION | awk -F. '{$NF = $NF + 1;} 1' | sed 's/ /./g')
        RELEASE_NOTES="Correções de bugs e melhorias de estabilidade"
        ;;
    2)
        # Minor version
        NEW_VERSION=$(echo $CURRENT_VERSION | awk -F. '{$(NF-1) = $(NF-1) + 1; $NF = 0;} 1' | sed 's/ /./g')
        RELEASE_NOTES="Novas funcionalidades e melhorias"
        ;;
    3)
        # Major version
        NEW_VERSION=$(echo $CURRENT_VERSION | awk -F. '{$(NF-2) = $(NF-2) + 1; $(NF-1) = 0; $NF = 0;} 1' | sed 's/ /./g')
        RELEASE_NOTES="Versão principal com mudanças significativas"
        ;;
    4)
        # Custom version
        read -p "Digite a nova versão (ex: 1.2.3): " NEW_VERSION
        read -p "Digite as notas do release: " RELEASE_NOTES
        ;;
    *)
        echo "❌ Opção inválida"
        exit 1
        ;;
esac

echo ""
echo "📋 Nova versão: $NEW_VERSION"
echo "📝 Notas: $RELEASE_NOTES"
echo ""

read -p "Confirma a criação do release? (y/N): " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "❌ Release cancelado"
    exit 1
fi

# Atualizar versão no build.gradle
echo "📝 Atualizando versão no build.gradle..."
sed -i "s/versionName \"$CURRENT_VERSION\"/versionName \"$NEW_VERSION\"/" app/build.gradle

# Atualizar versionCode (incrementar em 1)
CURRENT_CODE=$(grep 'versionCode' app/build.gradle | sed 's/.*versionCode \([0-9]*\).*/\1/')
NEW_CODE=$((CURRENT_CODE + 1))
sed -i "s/versionCode $CURRENT_CODE/versionCode $NEW_CODE/" app/build.gradle

echo "📝 Versão atualizada: $NEW_VERSION (code: $NEW_CODE)"

# Atualizar README se necessário
if [ -f "README.md" ]; then
    sed -i "s/\*\*Versão:\*\* [0-9]\+\.[0-9]\+\.[0-9]\+/**Versão:** $NEW_VERSION/" README.md
    echo "📝 README.md atualizado"
fi

# Commit das mudanças
echo "💾 Fazendo commit das mudanças..."
git add app/build.gradle README.md
git commit -m "chore: bump version to $NEW_VERSION

$RELEASE_NOTES"

# Criar tag
TAG_NAME="v$NEW_VERSION"
echo "🏷️  Criando tag $TAG_NAME..."
git tag -a "$TAG_NAME" -m "Release $NEW_VERSION

$RELEASE_NOTES"

# Push das mudanças e tag
echo "📤 Enviando mudanças para o repositório..."
git push origin main
git push origin "$TAG_NAME"

echo ""
echo "✅ Release $NEW_VERSION criado com sucesso!"
echo ""
echo "📋 O que acontece agora:"
echo "  1. GitHub Actions detectará a nova tag"
echo "  2. Build automático será iniciado"
echo "  3. APK será compilado e assinado"
echo "  4. Release será criado automaticamente no GitHub"
echo "  5. APK estará disponível para download"
echo ""
echo "🔗 Acompanhe o progresso em:"
echo "   https://github.com/$(git config --get remote.origin.url | sed 's/.*github.com[:/]\(.*\)\.git/\1/')/actions"
echo ""
echo "📱 O APK estará disponível em:"
echo "   https://github.com/$(git config --get remote.origin.url | sed 's/.*github.com[:/]\(.*\)\.git/\1/')/releases/tag/$TAG_NAME"
echo ""

