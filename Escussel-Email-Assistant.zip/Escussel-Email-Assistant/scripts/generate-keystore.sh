#!/bin/bash

# Script para gerar keystore para assinatura do APK
# Email Assistant - Manus AI

set -e

echo "🔑 Gerando Keystore para Email Assistant"
echo "========================================"

# Configurações padrão
KEYSTORE_NAME="emailassistant-release.jks"
KEY_ALIAS="emailassistant"
VALIDITY_DAYS=10000

# Solicitar informações do usuário
read -p "Nome da organização [Manus AI]: " ORG_NAME
ORG_NAME=${ORG_NAME:-"Manus AI"}

read -p "Nome do desenvolvedor [Email Assistant Team]: " DEV_NAME
DEV_NAME=${DEV_NAME:-"Email Assistant Team"}

read -p "Cidade [São Paulo]: " CITY
CITY=${CITY:-"São Paulo"}

read -p "Estado [SP]: " STATE
STATE=${STATE:-"SP"}

read -p "País [BR]: " COUNTRY
COUNTRY=${COUNTRY:-"BR"}

# Gerar senha segura se não fornecida
if [ -z "$KEYSTORE_PASSWORD" ]; then
    echo "Gerando senha segura para keystore..."
    KEYSTORE_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    echo "Senha gerada: $KEYSTORE_PASSWORD"
fi

if [ -z "$KEY_PASSWORD" ]; then
    echo "Gerando senha segura para chave..."
    KEY_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    echo "Senha da chave gerada: $KEY_PASSWORD"
fi

# Criar diretório se não existir
mkdir -p ../app

# Gerar keystore
echo "🔨 Gerando keystore..."
keytool -genkey -v \
    -keystore "../app/$KEYSTORE_NAME" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity $VALIDITY_DAYS \
    -storepass "$KEYSTORE_PASSWORD" \
    -keypass "$KEY_PASSWORD" \
    -dname "CN=$DEV_NAME, OU=$ORG_NAME, O=$ORG_NAME, L=$CITY, S=$STATE, C=$COUNTRY"

# Verificar keystore
echo "🔍 Verificando keystore..."
keytool -list -v -keystore "../app/$KEYSTORE_NAME" -storepass "$KEYSTORE_PASSWORD"

# Gerar arquivo de propriedades
echo "📝 Criando arquivo de propriedades..."
cat > ../keystore.properties << EOF
# Keystore properties for Email Assistant
# Generated on $(date)

storeFile=app/$KEYSTORE_NAME
storePassword=$KEYSTORE_PASSWORD
keyAlias=$KEY_ALIAS
keyPassword=$KEY_PASSWORD
EOF

# Converter keystore para base64 para GitHub Secrets
echo "🔐 Convertendo keystore para base64..."
KEYSTORE_BASE64=$(base64 -w 0 "../app/$KEYSTORE_NAME")

# Criar arquivo com secrets para GitHub
cat > ../github-secrets.txt << EOF
# GitHub Secrets para Email Assistant
# Adicione estes secrets no repositório GitHub em Settings > Secrets and variables > Actions

KEYSTORE_BASE64=$KEYSTORE_BASE64

KEYSTORE_PASSWORD=$KEYSTORE_PASSWORD

KEY_ALIAS=$KEY_ALIAS

KEY_PASSWORD=$KEY_PASSWORD
EOF

echo ""
echo "✅ Keystore gerado com sucesso!"
echo ""
echo "📁 Arquivos criados:"
echo "  - app/$KEYSTORE_NAME (keystore)"
echo "  - keystore.properties (propriedades locais)"
echo "  - github-secrets.txt (secrets para GitHub)"
echo ""
echo "🔒 IMPORTANTE:"
echo "  1. Mantenha o keystore e senhas em local seguro"
echo "  2. Adicione os secrets do arquivo github-secrets.txt no GitHub"
echo "  3. Não commite o keystore ou senhas no repositório"
echo "  4. Faça backup do keystore - sem ele não é possível atualizar o app"
echo ""
echo "📋 Próximos passos:"
echo "  1. Vá para Settings > Secrets and variables > Actions no GitHub"
echo "  2. Adicione cada secret do arquivo github-secrets.txt"
echo "  3. Execute o workflow de build para gerar APK assinado"
echo ""

