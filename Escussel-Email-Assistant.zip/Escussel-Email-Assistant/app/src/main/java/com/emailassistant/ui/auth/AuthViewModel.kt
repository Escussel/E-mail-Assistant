package com.emailassistant.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.emailassistant.data.auth.AuthTokenManager
import com.emailassistant.data.storage.ConfigurationManager
import com.emailassistant.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * ViewModel da tela de autenticação
 */
@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authTokenManager: AuthTokenManager,
    private val configurationManager: ConfigurationManager
) : BaseViewModel() {

    private val _authenticationSuccess = MutableLiveData<Boolean>()
    val authenticationSuccess: LiveData<Boolean> = _authenticationSuccess

    private val _userInfo = MutableLiveData<UserInfo?>()
    val userInfo: LiveData<UserInfo?> = _userInfo

    private val _authStatus = MutableLiveData<String>()
    val authStatus: LiveData<String> = _authStatus

    data class UserInfo(
        val displayName: String,
        val email: String,
        val id: String
    )

    init {
        _authStatus.value = "Pronto para autenticar"
    }

    suspend fun checkExistingAuthentication() {
        try {
            setLoading(true)
            _authStatus.value = "Verificando autenticação existente..."
            
            val hasValidToken = authTokenManager.hasValidToken()
            if (hasValidToken) {
                val userInfo = authTokenManager.getUserInfo()
                if (userInfo != null) {
                    _userInfo.value = UserInfo(
                        displayName = userInfo["displayName"] as? String ?: "Usuário",
                        email = userInfo["email"] as? String ?: "",
                        id = userInfo["id"] as? String ?: ""
                    )
                    _authStatus.value = "Já autenticado"
                    _authenticationSuccess.value = true
                } else {
                    _authStatus.value = "Token encontrado, mas informações do usuário indisponíveis"
                    signOut() // Limpar token inválido
                }
            } else {
                _authStatus.value = "Autenticação necessária"
            }
            
            setLoading(false)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao verificar autenticação existente")
            setError("Erro ao verificar autenticação: ${e.message}")
            _authStatus.value = "Erro na verificação"
            setLoading(false)
        }
    }

    suspend fun signIn() {
        try {
            setLoading(true)
            _authStatus.value = "Iniciando autenticação..."
            
            // Verificar se as configurações estão completas
            if (!configurationManager.isConfigurationComplete()) {
                setError("Configuração incompleta. Volte à tela de configuração.")
                setLoading(false)
                return
            }

            val clientId = configurationManager.getAzureClientId()
            if (clientId.isNullOrBlank()) {
                setError("Client ID do Azure não configurado")
                setLoading(false)
                return
            }

            _authStatus.value = "Conectando ao Microsoft Graph..."
            
            // Simular processo de autenticação OAuth
            // Em um aplicativo real, isso abriria o navegador para autenticação
            kotlinx.coroutines.delay(2000)
            
            // Simular sucesso na autenticação
            val mockToken = "mock_access_token_${System.currentTimeMillis()}"
            val mockRefreshToken = "mock_refresh_token_${System.currentTimeMillis()}"
            val expiresIn = 3600L // 1 hora
            
            authTokenManager.saveTokens(
                accessToken = mockToken,
                refreshToken = mockRefreshToken,
                expiresIn = expiresIn
            )
            
            // Simular informações do usuário
            val mockUserInfo = mapOf(
                "displayName" to "Usuário de Teste",
                "email" to "usuario@exemplo.com",
                "id" to "mock_user_id_123"
            )
            
            authTokenManager.saveUserInfo(mockUserInfo)
            
            _userInfo.value = UserInfo(
                displayName = mockUserInfo["displayName"] as String,
                email = mockUserInfo["email"] as String,
                id = mockUserInfo["id"] as String
            )
            
            _authStatus.value = "Autenticação concluída com sucesso!"
            _authenticationSuccess.value = true
            
            setLoading(false)
            Timber.d("Autenticação simulada com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro na autenticação")
            setError("Erro na autenticação: ${e.message}")
            _authStatus.value = "Falha na autenticação"
            setLoading(false)
        }
    }

    suspend fun signOut() {
        try {
            setLoading(true)
            _authStatus.value = "Desconectando..."
            
            authTokenManager.clearTokens()
            _userInfo.value = null
            _authenticationSuccess.value = false
            _authStatus.value = "Desconectado"
            
            setLoading(false)
            Timber.d("Logout realizado com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro no logout")
            setError("Erro ao desconectar: ${e.message}")
            setLoading(false)
        }
    }

    suspend fun retryAuthentication() {
        try {
            // Limpar estado de erro
            setError("")
            _authStatus.value = "Tentando novamente..."
            
            // Tentar autenticação novamente
            signIn()
        } catch (e: Exception) {
            Timber.e(e, "Erro na nova tentativa de autenticação")
            setError("Erro na nova tentativa: ${e.message}")
        }
    }

    suspend fun handleAuthenticationResult() {
        try {
            // Este método seria chamado quando o usuário retorna de uma autenticação externa
            // Por exemplo, após autenticar no navegador
            
            // Verificar se há novos tokens disponíveis
            checkExistingAuthentication()
        } catch (e: Exception) {
            Timber.e(e, "Erro ao processar resultado da autenticação")
            setError("Erro ao processar autenticação: ${e.message}")
        }
    }

    fun isAuthenticated(): Boolean {
        return authTokenManager.hasValidToken()
    }

    fun getCurrentUserInfo(): UserInfo? {
        return _userInfo.value
    }

    fun getAuthStatus(): String {
        return _authStatus.value ?: "Status desconhecido"
    }
}

