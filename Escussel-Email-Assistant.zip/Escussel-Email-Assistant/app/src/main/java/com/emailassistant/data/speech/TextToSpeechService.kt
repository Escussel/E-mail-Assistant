package com.emailassistant.data.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import timber.log.Timber
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

/**
 * Serviço de síntese de voz usando Android TextToSpeech
 */
@Singleton
class TextToSpeechService @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private var textToSpeech: TextToSpeech? = null
    private var isInitialized = false
    private var isSpeaking = false

    companion object {
        private const val LANGUAGE_CODE = "pt-BR"
        private const val DEFAULT_SPEECH_RATE = 1.0f
        private const val DEFAULT_PITCH = 1.0f
        private const val MAX_SPEECH_LENGTH = 4000 // Limite do Android TTS
    }

    /**
     * Inicializa o serviço TTS
     */
    suspend fun initialize(): Boolean = suspendCancellableCoroutine { continuation ->
        try {
            textToSpeech = TextToSpeech(context) { status ->
                when (status) {
                    TextToSpeech.SUCCESS -> {
                        val result = textToSpeech?.setLanguage(Locale.forLanguageTag(LANGUAGE_CODE))
                        isInitialized = when (result) {
                            TextToSpeech.LANG_MISSING_DATA,
                            TextToSpeech.LANG_NOT_SUPPORTED -> {
                                Timber.w("Idioma $LANGUAGE_CODE não suportado, usando padrão")
                                textToSpeech?.setLanguage(Locale.getDefault())
                                true
                            }
                            else -> true
                        }
                        
                        // Configurar parâmetros padrão
                        textToSpeech?.setSpeechRate(DEFAULT_SPEECH_RATE)
                        textToSpeech?.setPitch(DEFAULT_PITCH)
                        
                        Timber.d("TTS inicializado com sucesso")
                        continuation.resume(isInitialized)
                    }
                    else -> {
                        Timber.e("Falha ao inicializar TTS")
                        isInitialized = false
                        continuation.resume(false)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao inicializar TTS")
            continuation.resume(false)
        }
    }

    /**
     * Fala o texto fornecido
     */
    suspend fun speak(text: String, utteranceId: String = UUID.randomUUID().toString()): Flow<TTSResult> = callbackFlow {
        if (!isInitialized) {
            trySend(TTSResult.Error("TTS não inicializado"))
            close()
            return@callbackFlow
        }

        if (text.isBlank()) {
            trySend(TTSResult.Error("Texto vazio"))
            close()
            return@callbackFlow
        }

        try {
            val progressListener = object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    Timber.d("Iniciando fala: $utteranceId")
                    isSpeaking = true
                    trySend(TTSResult.Started(utteranceId ?: ""))
                }

                override fun onDone(utteranceId: String?) {
                    Timber.d("Fala concluída: $utteranceId")
                    isSpeaking = false
                    trySend(TTSResult.Completed(utteranceId ?: ""))
                    close()
                }

                override fun onError(utteranceId: String?) {
                    Timber.e("Erro na fala: $utteranceId")
                    isSpeaking = false
                    trySend(TTSResult.Error("Erro durante a síntese de voz"))
                    close()
                }

                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    // Progresso da fala
                    trySend(TTSResult.Progress(utteranceId ?: "", start, end))
                }
            }

            textToSpeech?.setOnUtteranceProgressListener(progressListener)

            // Dividir texto longo em partes menores
            val textParts = splitTextForTTS(text)
            
            for ((index, part) in textParts.withIndex()) {
                val partId = "${utteranceId}_part_$index"
                val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                
                val result = textToSpeech?.speak(part, queueMode, null, partId)
                
                if (result != TextToSpeech.SUCCESS) {
                    trySend(TTSResult.Error("Falha ao iniciar síntese de voz"))
                    close()
                    return@callbackFlow
                }
            }

        } catch (e: Exception) {
            Timber.e(e, "Erro ao falar texto")
            trySend(TTSResult.Error("Erro ao falar: ${e.message}"))
            close()
        }

        awaitClose {
            // Cleanup se necessário
        }
    }

    /**
     * Para a síntese de voz
     */
    fun stop() {
        try {
            textToSpeech?.stop()
            isSpeaking = false
            Timber.d("TTS parado")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao parar TTS")
        }
    }

    /**
     * Verifica se está falando
     */
    fun isSpeaking(): Boolean = isSpeaking

    /**
     * Define velocidade da fala
     */
    fun setSpeechRate(rate: Float): Boolean {
        return try {
            val result = textToSpeech?.setSpeechRate(rate.coerceIn(0.1f, 3.0f))
            result == TextToSpeech.SUCCESS
        } catch (e: Exception) {
            Timber.e(e, "Erro ao definir velocidade da fala")
            false
        }
    }

    /**
     * Define tom da voz
     */
    fun setPitch(pitch: Float): Boolean {
        return try {
            val result = textToSpeech?.setPitch(pitch.coerceIn(0.1f, 2.0f))
            result == TextToSpeech.SUCCESS
        } catch (e: Exception) {
            Timber.e(e, "Erro ao definir tom da voz")
            false
        }
    }

    /**
     * Obtém idiomas disponíveis
     */
    fun getAvailableLanguages(): Set<Locale> {
        return try {
            textToSpeech?.availableLanguages ?: emptySet()
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter idiomas disponíveis")
            emptySet()
        }
    }

    /**
     * Define idioma
     */
    fun setLanguage(locale: Locale): Boolean {
        return try {
            val result = textToSpeech?.setLanguage(locale)
            when (result) {
                TextToSpeech.LANG_MISSING_DATA,
                TextToSpeech.LANG_NOT_SUPPORTED -> false
                else -> true
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao definir idioma")
            false
        }
    }

    /**
     * Libera recursos
     */
    fun shutdown() {
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
            isInitialized = false
            isSpeaking = false
            Timber.d("TTS finalizado")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao finalizar TTS")
        }
    }

    /**
     * Divide texto longo em partes menores para TTS
     */
    private fun splitTextForTTS(text: String): List<String> {
        if (text.length <= MAX_SPEECH_LENGTH) {
            return listOf(text)
        }

        val parts = mutableListOf<String>()
        var currentPart = ""
        
        // Dividir por sentenças
        val sentences = text.split(Regex("[.!?]+"))
        
        for (sentence in sentences) {
            val trimmedSentence = sentence.trim()
            if (trimmedSentence.isEmpty()) continue
            
            val sentenceWithPunctuation = "$trimmedSentence."
            
            if (currentPart.length + sentenceWithPunctuation.length <= MAX_SPEECH_LENGTH) {
                currentPart += if (currentPart.isEmpty()) sentenceWithPunctuation else " $sentenceWithPunctuation"
            } else {
                if (currentPart.isNotEmpty()) {
                    parts.add(currentPart)
                }
                currentPart = sentenceWithPunctuation
            }
        }
        
        if (currentPart.isNotEmpty()) {
            parts.add(currentPart)
        }
        
        return parts.ifEmpty { listOf(text) }
    }
}

/**
 * Resultado da síntese de voz
 */
sealed class TTSResult {
    data class Started(val utteranceId: String) : TTSResult()
    data class Progress(val utteranceId: String, val start: Int, val end: Int) : TTSResult()
    data class Completed(val utteranceId: String) : TTSResult()
    data class Error(val message: String) : TTSResult()
}

