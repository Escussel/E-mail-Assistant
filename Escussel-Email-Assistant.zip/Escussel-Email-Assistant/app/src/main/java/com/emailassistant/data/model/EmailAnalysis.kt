package com.emailassistant.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Resultado da análise inteligente de e-mails
 */
@Parcelize
data class EmailAnalysis(
    val emails: List<Email>,
    val summary: String,
    val keyTopics: List<String>,
    val sentimentAnalysis: SentimentAnalysis,
    val similarityGroups: List<SimilarityGroup>,
    val actionableItems: List<ActionableItem>,
    val conversationContext: ConversationContext
) : Parcelable

@Parcelize
data class SentimentAnalysis(
    val overallSentiment: Sentiment,
    val confidenceScore: Float,
    val emotionalTone: List<EmotionalTone>
) : Parcelable

@Parcelize
enum class Sentiment : Parcelable {
    POSITIVE, NEUTRAL, NEGATIVE
}

@Parcelize
data class EmotionalTone(
    val emotion: String,
    val intensity: Float
) : Parcelable

@Parcelize
data class SimilarityGroup(
    val id: String,
    val emails: List<Email>,
    val commonTheme: String,
    val similarityScore: Float
) : Parcelable

@Parcelize
data class ActionableItem(
    val type: ActionType,
    val description: String,
    val priority: Priority,
    val relatedEmails: List<String>
) : Parcelable

@Parcelize
enum class ActionType : Parcelable {
    REPLY_REQUIRED, MEETING_REQUEST, DEADLINE, FOLLOW_UP, INFORMATION_REQUEST
}

@Parcelize
enum class Priority : Parcelable {
    LOW, MEDIUM, HIGH, URGENT
}

@Parcelize
data class ConversationContext(
    val previousQuestions: List<String>,
    val currentFocus: String,
    val availableActions: List<String>
) : Parcelable

