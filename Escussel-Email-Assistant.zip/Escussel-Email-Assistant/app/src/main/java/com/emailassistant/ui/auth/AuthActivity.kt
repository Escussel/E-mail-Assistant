package com.emailassistant.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.emailassistant.databinding.ActivityAuthBinding
import com.emailassistant.ui.main.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Atividade de autenticação com Microsoft Graph
 */
@AndroidEntryPoint
class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()
        setupClickListeners()
        checkExistingAuth()
    }

    private fun setupObservers() {
        // Observar estado de carregamento
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
            
            // Desabilitar botões durante carregamento
            binding.btnSignIn.isEnabled = !isLoading
            binding.btnRetry.isEnabled = !isLoading
        }

        // Observar mensagens de erro
        viewModel.errorMessage.observe(this) { error ->
            if (error.isNotEmpty()) {
                binding.tvErrorMessage.text = error
                binding.tvErrorMessage.visibility = android.view.View.VISIBLE
                binding.btnRetry.visibility = android.view.View.VISIBLE
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            } else {
                binding.tvErrorMessage.visibility = android.view.View.GONE
                binding.btnRetry.visibility = android.view.View.GONE
            }
        }

        // Observar sucesso na autenticação
        viewModel.authenticationSuccess.observe(this) { success ->
            if (success) {
                binding.tvStatus.text = "Autenticação realizada com sucesso!"
                binding.tvStatus.setTextColor(getColor(com.emailassistant.R.color.green_500))
                
                // Aguardar um momento e ir para a tela principal
                lifecycleScope.launch {
                    kotlinx.coroutines.delay(1500)
                    startActivity(Intent(this@AuthActivity, MainActivity::class.java))
                    finish()
                }
            }
        }

        // Observar informações do usuário
        viewModel.userInfo.observe(this) { userInfo ->
            if (userInfo != null) {
                binding.tvUserInfo.text = "Conectado como: ${userInfo.displayName}\n${userInfo.email}"
                binding.tvUserInfo.visibility = android.view.View.VISIBLE
            } else {
                binding.tvUserInfo.visibility = android.view.View.GONE
            }
        }

        // Observar status da autenticação
        viewModel.authStatus.observe(this) { status ->
            binding.tvStatus.text = status
        }
    }

    private fun setupClickListeners() {
        // Botão de login
        binding.btnSignIn.setOnClickListener {
            lifecycleScope.launch {
                viewModel.signIn()
            }
        }

        // Botão de tentar novamente
        binding.btnRetry.setOnClickListener {
            lifecycleScope.launch {
                viewModel.retryAuthentication()
            }
        }

        // Botão de logout
        binding.btnSignOut.setOnClickListener {
            lifecycleScope.launch {
                viewModel.signOut()
            }
        }

        // Botão voltar
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Link de ajuda
        binding.tvHelpLink.setOnClickListener {
            showHelpDialog()
        }
    }

    private fun checkExistingAuth() {
        lifecycleScope.launch {
            viewModel.checkExistingAuthentication()
        }
    }

    private fun showHelpDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Ajuda com Autenticação")
            .setMessage("""
                Para usar o Email Assistant, você precisa:
                
                1. Ter uma conta Microsoft (Outlook, Hotmail, ou Office 365)
                2. Permitir que o aplicativo acesse seus e-mails
                3. Configurar as chaves de API necessárias
                
                Se você não tem uma conta Microsoft, pode criar uma gratuitamente em outlook.com.
                
                Para problemas de autenticação, verifique:
                - Conexão com a internet
                - Configurações de API na tela anterior
                - Se sua conta Microsoft está ativa
            """.trimIndent())
            .setPositiveButton("Entendi") { dialog, _ ->
                dialog.dismiss()
            }
            .setNegativeButton("Voltar às Configurações") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        // Verificar se voltou de uma autenticação externa
        lifecycleScope.launch {
            viewModel.handleAuthenticationResult()
        }
    }
}

