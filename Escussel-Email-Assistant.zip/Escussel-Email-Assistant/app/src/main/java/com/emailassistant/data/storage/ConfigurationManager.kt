package com.emailassistant.data.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gerenciador de configurações do aplicativo
 */
@Singleton
class ConfigurationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            "app_config",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private val regularPrefs: SharedPreferences by lazy {
        context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
    }

    companion object {
        // Chaves para configurações sensíveis (criptografadas)
        private const val KEY_OPENAI_API_KEY = "openai_api_key"
        private const val KEY_AZURE_CLIENT_ID = "azure_client_id"
        private const val KEY_AZURE_CLIENT_SECRET = "azure_client_secret"
        
        // Chaves para configurações gerais (não criptografadas)
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_VOICE_FEEDBACK_ENABLED = "voice_feedback_enabled"
        private const val KEY_HANDS_FREE_MODE = "hands_free_mode"
        private const val KEY_AUTO_ARCHIVE_DAYS = "auto_archive_days"
        private const val KEY_NOTIFICATION_ENABLED = "notification_enabled"
        private const val KEY_FIRST_SETUP_COMPLETED = "first_setup_completed"
        
        // Valores padrão
        private const val DEFAULT_SPEECH_RATE = 1.0f
        private const val DEFAULT_SPEECH_PITCH = 1.0f
        private const val DEFAULT_LANGUAGE = "pt-BR"
        private const val DEFAULT_AUTO_ARCHIVE_DAYS = 30
    }

    // Configurações de API (criptografadas)

    suspend fun setOpenAIApiKey(apiKey: String) = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.edit().putString(KEY_OPENAI_API_KEY, apiKey).apply()
            Timber.d("Chave OpenAI salva")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao salvar chave OpenAI")
        }
    }

    suspend fun getOpenAIApiKey(): String? = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.getString(KEY_OPENAI_API_KEY, null)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter chave OpenAI")
            null
        }
    }

    suspend fun setAzureClientId(clientId: String) = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.edit().putString(KEY_AZURE_CLIENT_ID, clientId).apply()
            Timber.d("Client ID Azure salvo")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao salvar Client ID Azure")
        }
    }

    suspend fun getAzureClientId(): String? = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.getString(KEY_AZURE_CLIENT_ID, null)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter Client ID Azure")
            null
        }
    }

    suspend fun setAzureClientSecret(clientSecret: String) = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.edit().putString(KEY_AZURE_CLIENT_SECRET, clientSecret).apply()
            Timber.d("Client Secret Azure salvo")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao salvar Client Secret Azure")
        }
    }

    suspend fun getAzureClientSecret(): String? = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.getString(KEY_AZURE_CLIENT_SECRET, null)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter Client Secret Azure")
            null
        }
    }

    // Configurações de voz

    fun setSpeechRate(rate: Float) {
        regularPrefs.edit().putFloat(KEY_SPEECH_RATE, rate).apply()
        Timber.d("Velocidade da fala definida: $rate")
    }

    fun getSpeechRate(): Float {
        return regularPrefs.getFloat(KEY_SPEECH_RATE, DEFAULT_SPEECH_RATE)
    }

    fun setSpeechPitch(pitch: Float) {
        regularPrefs.edit().putFloat(KEY_SPEECH_PITCH, pitch).apply()
        Timber.d("Tom da voz definido: $pitch")
    }

    fun getSpeechPitch(): Float {
        return regularPrefs.getFloat(KEY_SPEECH_PITCH, DEFAULT_SPEECH_PITCH)
    }

    fun setLanguage(language: String) {
        regularPrefs.edit().putString(KEY_LANGUAGE, language).apply()
        Timber.d("Idioma definido: $language")
    }

    fun getLanguage(): String {
        return regularPrefs.getString(KEY_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
    }

    // Configurações de comportamento

    fun setVoiceFeedbackEnabled(enabled: Boolean) {
        regularPrefs.edit().putBoolean(KEY_VOICE_FEEDBACK_ENABLED, enabled).apply()
        Timber.d("Feedback de voz: $enabled")
    }

    fun isVoiceFeedbackEnabled(): Boolean {
        return regularPrefs.getBoolean(KEY_VOICE_FEEDBACK_ENABLED, true)
    }

    fun setHandsFreeMode(enabled: Boolean) {
        regularPrefs.edit().putBoolean(KEY_HANDS_FREE_MODE, enabled).apply()
        Timber.d("Modo hands-free: $enabled")
    }

    fun isHandsFreeModeEnabled(): Boolean {
        return regularPrefs.getBoolean(KEY_HANDS_FREE_MODE, false)
    }

    fun setAutoArchiveDays(days: Int) {
        regularPrefs.edit().putInt(KEY_AUTO_ARCHIVE_DAYS, days).apply()
        Timber.d("Auto-arquivamento: $days dias")
    }

    fun getAutoArchiveDays(): Int {
        return regularPrefs.getInt(KEY_AUTO_ARCHIVE_DAYS, DEFAULT_AUTO_ARCHIVE_DAYS)
    }

    fun setNotificationEnabled(enabled: Boolean) {
        regularPrefs.edit().putBoolean(KEY_NOTIFICATION_ENABLED, enabled).apply()
        Timber.d("Notificações: $enabled")
    }

    fun isNotificationEnabled(): Boolean {
        return regularPrefs.getBoolean(KEY_NOTIFICATION_ENABLED, true)
    }

    // Configurações de setup

    fun setFirstSetupCompleted(completed: Boolean) {
        regularPrefs.edit().putBoolean(KEY_FIRST_SETUP_COMPLETED, completed).apply()
        Timber.d("Primeiro setup concluído: $completed")
    }

    fun isFirstSetupCompleted(): Boolean {
        return regularPrefs.getBoolean(KEY_FIRST_SETUP_COMPLETED, false)
    }

    // Métodos utilitários

    suspend fun clearAllConfiguration() = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.edit().clear().apply()
            regularPrefs.edit().clear().apply()
            Timber.d("Todas as configurações foram limpas")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao limpar configurações")
        }
    }

    suspend fun isConfigurationComplete(): Boolean = withContext(Dispatchers.IO) {
        val hasOpenAIKey = getOpenAIApiKey() != null
        val hasAzureConfig = getAzureClientId() != null
        val setupCompleted = isFirstSetupCompleted()
        
        return@withContext hasOpenAIKey && hasAzureConfig && setupCompleted
    }

    fun exportConfiguration(): Map<String, Any> {
        return mapOf(
            "speech_rate" to getSpeechRate(),
            "speech_pitch" to getSpeechPitch(),
            "language" to getLanguage(),
            "voice_feedback_enabled" to isVoiceFeedbackEnabled(),
            "hands_free_mode" to isHandsFreeModeEnabled(),
            "auto_archive_days" to getAutoArchiveDays(),
            "notification_enabled" to isNotificationEnabled(),
            "first_setup_completed" to isFirstSetupCompleted()
        )
    }

    fun importConfiguration(config: Map<String, Any>) {
        try {
            config["speech_rate"]?.let { setSpeechRate(it as Float) }
            config["speech_pitch"]?.let { setSpeechPitch(it as Float) }
            config["language"]?.let { setLanguage(it as String) }
            config["voice_feedback_enabled"]?.let { setVoiceFeedbackEnabled(it as Boolean) }
            config["hands_free_mode"]?.let { setHandsFreeMode(it as Boolean) }
            config["auto_archive_days"]?.let { setAutoArchiveDays(it as Int) }
            config["notification_enabled"]?.let { setNotificationEnabled(it as Boolean) }
            config["first_setup_completed"]?.let { setFirstSetupCompleted(it as Boolean) }
            
            Timber.d("Configurações importadas com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao importar configurações")
        }
    }
}

