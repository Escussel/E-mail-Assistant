package com.emailassistant.data.api

import com.emailassistant.data.api.dto.EmailDto
import com.emailassistant.data.api.dto.EmailListResponse
import com.emailassistant.data.api.dto.FolderDto
import com.emailassistant.data.api.dto.FolderListResponse
import com.emailassistant.data.api.dto.SendEmailRequest
import retrofit2.Response
import retrofit2.http.*

/**
 * Interface da API do Microsoft Graph para operações de e-mail
 */
interface MicrosoftGraphApi {

    /**
     * Obtém e-mails da caixa de entrada
     */
    @GET("me/messages")
    suspend fun getMessages(
        @Header("Authorization") authorization: String,
        @Query("\$filter") filter: String? = null,
        @Query("\$orderby") orderBy: String = "receivedDateTime desc",
        @Query("\$top") top: Int = 50,
        @Query("\$skip") skip: Int = 0,
        @Query("\$select") select: String = "id,subject,sender,toRecipients,body,bodyPreview,receivedDateTime,isRead,importance,hasAttachments,conversationId,categories,flag"
    ): Response<EmailListResponse>

    /**
     * Obtém um e-mail específico por ID
     */
    @GET("me/messages/{messageId}")
    suspend fun getMessage(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String,
        @Query("\$select") select: String = "id,subject,sender,toRecipients,body,bodyPreview,receivedDateTime,isRead,importance,hasAttachments,conversationId,categories,flag"
    ): Response<EmailDto>

    /**
     * Envia um novo e-mail
     */
    @POST("me/sendMail")
    suspend fun sendEmail(
        @Header("Authorization") authorization: String,
        @Body emailRequest: SendEmailRequest
    ): Response<Unit>

    /**
     * Responde a um e-mail
     */
    @POST("me/messages/{messageId}/reply")
    suspend fun replyToEmail(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String,
        @Body replyRequest: SendEmailRequest
    ): Response<Unit>

    /**
     * Responde a todos de um e-mail
     */
    @POST("me/messages/{messageId}/replyAll")
    suspend fun replyToAllEmail(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String,
        @Body replyRequest: SendEmailRequest
    ): Response<Unit>

    /**
     * Marca e-mail como lido/não lido
     */
    @PATCH("me/messages/{messageId}")
    suspend fun updateMessage(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String,
        @Body updateRequest: Map<String, Any>
    ): Response<Unit>

    /**
     * Move e-mail para uma pasta
     */
    @POST("me/messages/{messageId}/move")
    suspend fun moveMessage(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String,
        @Body moveRequest: Map<String, String>
    ): Response<EmailDto>

    /**
     * Exclui um e-mail
     */
    @DELETE("me/messages/{messageId}")
    suspend fun deleteMessage(
        @Header("Authorization") authorization: String,
        @Path("messageId") messageId: String
    ): Response<Unit>

    /**
     * Obtém pastas de e-mail
     */
    @GET("me/mailFolders")
    suspend fun getMailFolders(
        @Header("Authorization") authorization: String,
        @Query("\$select") select: String = "id,displayName,parentFolderId,childFolderCount,unreadItemCount,totalItemCount"
    ): Response<FolderListResponse>

    /**
     * Obtém pasta específica por nome
     */
    @GET("me/mailFolders")
    suspend fun getFolderByName(
        @Header("Authorization") authorization: String,
        @Query("\$filter") filter: String, // displayName eq 'Archive'
        @Query("\$select") select: String = "id,displayName,parentFolderId"
    ): Response<FolderListResponse>

    /**
     * Busca e-mails por query
     */
    @GET("me/messages")
    suspend fun searchMessages(
        @Header("Authorization") authorization: String,
        @Query("\$search") search: String,
        @Query("\$orderby") orderBy: String = "receivedDateTime desc",
        @Query("\$top") top: Int = 50,
        @Query("\$select") select: String = "id,subject,sender,toRecipients,body,bodyPreview,receivedDateTime,isRead,importance,hasAttachments,conversationId,categories,flag"
    ): Response<EmailListResponse>
}

