package com.emailassistant.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.emailassistant.data.model.Email
import com.emailassistant.data.model.EmailAnalysis
import com.emailassistant.data.model.VoiceCommand
import com.emailassistant.data.repository.AIAnalysisRepository
import com.emailassistant.data.repository.EmailRepository
import com.emailassistant.data.repository.SpeechRepository
import com.emailassistant.data.storage.ConfigurationManager
import com.emailassistant.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import timber.log.Timber
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject

/**
 * ViewModel da tela principal
 */
@HiltViewModel
class MainViewModel @Inject constructor(
    private val speechRepository: SpeechRepository,
    private val emailRepository: EmailRepository,
    private val aiAnalysisRepository: AIAnalysisRepository,
    private val configurationManager: ConfigurationManager
) : BaseViewModel() {

    private val _isConfigured = MutableLiveData<Boolean>()
    val isConfigured: LiveData<Boolean> = _isConfigured

    private val _isAuthenticated = MutableLiveData<Boolean>()
    val isAuthenticated: LiveData<Boolean> = _isAuthenticated

    private val _isListening = MutableLiveData<Boolean>()
    val isListening: LiveData<Boolean> = _isListening

    private val _recognizedText = MutableLiveData<String>()
    val recognizedText: LiveData<String> = _recognizedText

    private val _aiResponse = MutableLiveData<String>()
    val aiResponse: LiveData<String> = _aiResponse

    private val _emailAnalysis = MutableLiveData<EmailAnalysis?>()
    val emailAnalysis: LiveData<EmailAnalysis?> = _emailAnalysis

    private val _handsFreeMode = MutableLiveData<Boolean>()
    val handsFreeMode: LiveData<Boolean> = _handsFreeMode

    private var currentEmails: List<Email> = emptyList()
    private var conversationHistory: MutableList<String> = mutableListOf()

    init {
        _isListening.value = false
        _handsFreeMode.value = configurationManager.isHandsFreeModeEnabled()
    }

    suspend fun initialize() {
        try {
            setLoading(true)
            
            // Verificar configuração
            val isConfigured = configurationManager.isConfigurationComplete()
            _isConfigured.value = isConfigured
            
            if (!isConfigured) {
                setLoading(false)
                return
            }

            // Verificar autenticação
            checkAuthentication()
            
            // Carregar e-mails recentes
            loadRecentEmails()
            
            setLoading(false)
            Timber.d("Aplicativo inicializado com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao inicializar aplicativo")
            setError("Erro ao inicializar: ${e.message}")
            setLoading(false)
        }
    }

    fun checkConfiguration() {
        viewModelScope.launch {
            val isConfigured = configurationManager.isConfigurationComplete()
            _isConfigured.value = isConfigured
        }
    }

    private suspend fun checkAuthentication() {
        try {
            // Verificar se há token válido
            val hasValidToken = emailRepository.hasValidToken()
            _isAuthenticated.value = hasValidToken
        } catch (e: Exception) {
            Timber.e(e, "Erro ao verificar autenticação")
            _isAuthenticated.value = false
        }
    }

    fun startListening() {
        viewModelScope.launch {
            try {
                val result = speechRepository.startListening()
                result.fold(
                    onSuccess = {
                        _isListening.value = true
                        collectRecognizedText()
                        Timber.d("Reconhecimento de voz iniciado")
                    },
                    onFailure = { exception ->
                        setError("Erro ao iniciar reconhecimento: ${exception.message}")
                        Timber.e(exception, "Erro ao iniciar reconhecimento")
                    }
                )
            } catch (e: Exception) {
                setError("Erro inesperado: ${e.message}")
                Timber.e(e, "Erro inesperado ao iniciar reconhecimento")
            }
        }
    }

    fun stopListening() {
        viewModelScope.launch {
            try {
                speechRepository.stopListening()
                _isListening.value = false
                Timber.d("Reconhecimento de voz parado")
            } catch (e: Exception) {
                Timber.e(e, "Erro ao parar reconhecimento")
            }
        }
    }

    fun stopSpeaking() {
        viewModelScope.launch {
            try {
                speechRepository.stopSpeaking()
                Timber.d("Síntese de voz parada")
            } catch (e: Exception) {
                Timber.e(e, "Erro ao parar síntese de voz")
            }
        }
    }

    fun toggleHandsFreeMode() {
        val newMode = !(_handsFreeMode.value ?: false)
        _handsFreeMode.value = newMode
        configurationManager.setHandsFreeMode(newMode)
        
        if (newMode) {
            startContinuousListening()
        } else {
            stopListening()
        }
    }

    fun analyzeRecentEmails() {
        viewModelScope.launch {
            try {
                setLoading(true)
                
                if (currentEmails.isEmpty()) {
                    loadRecentEmails()
                }
                
                if (currentEmails.isNotEmpty()) {
                    val analysisResult = aiAnalysisRepository.analyzeEmails(currentEmails)
                    analysisResult.fold(
                        onSuccess = { analysis ->
                            _emailAnalysis.value = analysis
                            speakAnalysisSummary(analysis.summary)
                            Timber.d("Análise de e-mails concluída")
                        },
                        onFailure = { exception ->
                            setError("Erro na análise: ${exception.message}")
                            Timber.e(exception, "Erro na análise de e-mails")
                        }
                    )
                } else {
                    setError("Nenhum e-mail encontrado para análise")
                }
                
                setLoading(false)
            } catch (e: Exception) {
                setError("Erro inesperado: ${e.message}")
                setLoading(false)
                Timber.e(e, "Erro inesperado na análise")
            }
        }
    }

    private fun collectRecognizedText() {
        viewModelScope.launch {
            speechRepository.getRecognizedText()
                .onEach { text ->
                    if (text.isNotBlank()) {
                        _recognizedText.value = text
                        processVoiceCommand(text)
                    }
                }
                .catch { exception ->
                    Timber.e(exception, "Erro ao coletar texto reconhecido")
                    setError("Erro no reconhecimento: ${exception.message}")
                }
                .collect { }
        }
    }

    private suspend fun processVoiceCommand(recognizedText: String) {
        try {
            // Processar comando de voz
            val commandResult = speechRepository.processVoiceCommand(recognizedText)
            commandResult.fold(
                onSuccess = { command ->
                    executeVoiceCommand(command)
                },
                onFailure = { exception ->
                    setError("Erro ao processar comando: ${exception.message}")
                    Timber.e(exception, "Erro ao processar comando")
                }
            )
        } catch (e: Exception) {
            setError("Erro inesperado: ${e.message}")
            Timber.e(e, "Erro inesperado ao processar comando")
        }
    }

    private suspend fun executeVoiceCommand(command: VoiceCommand) {
        try {
            val executionResult = speechRepository.executeVoiceCommand(command)
            executionResult.fold(
                onSuccess = { result ->
                    if (result.success) {
                        _aiResponse.value = result.response
                        speakResponse(result.response)
                        
                        // Executar ação específica baseada no comando
                        when (command.intent) {
                            com.emailassistant.data.model.CommandIntent.ANALYZE_EMAILS -> {
                                analyzeEmailsFromCommand(command)
                            }
                            com.emailassistant.data.model.CommandIntent.ARCHIVE_EMAIL -> {
                                archiveEmailFromCommand(command)
                            }
                            com.emailassistant.data.model.CommandIntent.DELETE_EMAIL -> {
                                deleteEmailFromCommand(command)
                            }
                            com.emailassistant.data.model.CommandIntent.ASK_QUESTION -> {
                                answerQuestionFromCommand(command)
                            }
                            else -> {
                                // Outros comandos já processados
                            }
                        }
                    } else {
                        setError(result.error ?: "Erro desconhecido")
                    }
                },
                onFailure = { exception ->
                    setError("Erro na execução: ${exception.message}")
                    Timber.e(exception, "Erro na execução do comando")
                }
            )
        } catch (e: Exception) {
            setError("Erro inesperado: ${e.message}")
            Timber.e(e, "Erro inesperado na execução")
        }
    }

    private suspend fun loadRecentEmails() {
        try {
            val endDate = LocalDateTime.now()
            val startDate = endDate.minusDays(7) // Últimos 7 dias
            
            val emailsResult = emailRepository.getEmailsByDateRange(
                startDate = startDate.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                endDate = endDate.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
            )
            
            emailsResult.fold(
                onSuccess = { emails ->
                    currentEmails = emails
                    Timber.d("Carregados ${emails.size} e-mails recentes")
                },
                onFailure = { exception ->
                    setError("Erro ao carregar e-mails: ${exception.message}")
                    Timber.e(exception, "Erro ao carregar e-mails")
                }
            )
        } catch (e: Exception) {
            setError("Erro inesperado: ${e.message}")
            Timber.e(e, "Erro inesperado ao carregar e-mails")
        }
    }

    private suspend fun analyzeEmailsFromCommand(command: VoiceCommand) {
        // Implementar análise baseada nos parâmetros do comando
        analyzeRecentEmails()
    }

    private suspend fun archiveEmailFromCommand(command: VoiceCommand) {
        try {
            val emailId = command.parameters["emailId"] as? String
            if (emailId != null) {
                val result = emailRepository.archiveEmail(emailId)
                result.fold(
                    onSuccess = {
                        speakResponse("E-mail arquivado com sucesso")
                    },
                    onFailure = { exception ->
                        setError("Erro ao arquivar: ${exception.message}")
                    }
                )
            } else {
                setError("ID do e-mail não especificado")
            }
        } catch (e: Exception) {
            setError("Erro ao arquivar e-mail: ${e.message}")
        }
    }

    private suspend fun deleteEmailFromCommand(command: VoiceCommand) {
        try {
            val emailId = command.parameters["emailId"] as? String
            if (emailId != null) {
                val result = emailRepository.deleteEmail(emailId)
                result.fold(
                    onSuccess = {
                        speakResponse("E-mail excluído com sucesso")
                    },
                    onFailure = { exception ->
                        setError("Erro ao excluir: ${exception.message}")
                    }
                )
            } else {
                setError("ID do e-mail não especificado")
            }
        } catch (e: Exception) {
            setError("Erro ao excluir e-mail: ${e.message}")
        }
    }

    private suspend fun answerQuestionFromCommand(command: VoiceCommand) {
        try {
            val question = command.parameters["question"] as? String
            if (question != null && currentEmails.isNotEmpty()) {
                val answerResult = aiAnalysisRepository.answerQuestion(
                    question = question,
                    emails = currentEmails,
                    conversationHistory = conversationHistory
                )
                
                answerResult.fold(
                    onSuccess = { answer ->
                        _aiResponse.value = answer
                        speakResponse(answer)
                        
                        // Adicionar ao histórico da conversa
                        conversationHistory.add(question)
                        conversationHistory.add(answer)
                        
                        // Manter apenas as últimas 10 interações
                        if (conversationHistory.size > 20) {
                            conversationHistory = conversationHistory.takeLast(20).toMutableList()
                        }
                    },
                    onFailure = { exception ->
                        setError("Erro ao responder pergunta: ${exception.message}")
                    }
                )
            } else {
                setError("Pergunta não especificada ou nenhum e-mail disponível")
            }
        } catch (e: Exception) {
            setError("Erro ao processar pergunta: ${e.message}")
        }
    }

    private suspend fun speakResponse(text: String) {
        if (configurationManager.isVoiceFeedbackEnabled()) {
            speechRepository.speakText(text)
        }
    }

    private suspend fun speakAnalysisSummary(summary: String) {
        val shortSummary = if (summary.length > 200) {
            summary.take(200) + "..."
        } else {
            summary
        }
        speakResponse(shortSummary)
    }

    private fun startContinuousListening() {
        // Implementar escuta contínua para modo hands-free
        viewModelScope.launch {
            while (_handsFreeMode.value == true) {
                if (!(_isListening.value ?: false)) {
                    startListening()
                }
                kotlinx.coroutines.delay(1000) // Verificar a cada segundo
            }
        }
    }

    fun cleanup() {
        viewModelScope.launch {
            try {
                stopListening()
                stopSpeaking()
                Timber.d("Cleanup concluído")
            } catch (e: Exception) {
                Timber.e(e, "Erro no cleanup")
            }
        }
    }
}

