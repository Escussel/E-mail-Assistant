package com.emailassistant.data.api.dto

import com.google.gson.annotations.SerializedName

/**
 * DTO para requisição de envio de e-mail
 */
data class SendEmailRequest(
    @SerializedName("message")
    val message: MessageDto,
    @SerializedName("saveToSentItems")
    val saveToSentItems: Boolean = true
)

/**
 * DTO para mensagem a ser enviada
 */
data class MessageDto(
    @SerializedName("subject")
    val subject: String,
    @SerializedName("body")
    val body: EmailBodyDto,
    @SerializedName("toRecipients")
    val toRecipients: List<EmailAddressDto>,
    @SerializedName("ccRecipients")
    val ccRecipients: List<EmailAddressDto>? = null,
    @SerializedName("bccRecipients")
    val bccRecipients: List<EmailAddressDto>? = null,
    @SerializedName("importance")
    val importance: String = "normal" // low, normal, high
)

/**
 * DTO para resposta a e-mail
 */
data class ReplyEmailRequest(
    @SerializedName("comment")
    val comment: String,
    @SerializedName("message")
    val message: MessageDto? = null
)

/**
 * Classe utilitária para criar DTOs de e-mail
 */
object EmailDtoFactory {
    
    fun createEmailAddress(name: String, address: String): EmailAddressDto {
        return EmailAddressDto(
            emailAddress = EmailAddressInfoDto(
                name = name,
                address = address
            )
        )
    }
    
    fun createEmailBody(content: String, contentType: String = "HTML"): EmailBodyDto {
        return EmailBodyDto(
            contentType = contentType,
            content = content
        )
    }
    
    fun createSendEmailRequest(
        subject: String,
        body: String,
        toRecipients: List<Pair<String, String>>, // (name, address)
        ccRecipients: List<Pair<String, String>>? = null,
        importance: String = "normal"
    ): SendEmailRequest {
        return SendEmailRequest(
            message = MessageDto(
                subject = subject,
                body = createEmailBody(body),
                toRecipients = toRecipients.map { (name, address) ->
                    createEmailAddress(name, address)
                },
                ccRecipients = ccRecipients?.map { (name, address) ->
                    createEmailAddress(name, address)
                },
                importance = importance
            )
        )
    }
    
    fun createReplyRequest(comment: String): ReplyEmailRequest {
        return ReplyEmailRequest(comment = comment)
    }
}

