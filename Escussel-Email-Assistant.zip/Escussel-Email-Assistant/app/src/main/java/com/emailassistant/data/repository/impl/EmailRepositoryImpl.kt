package com.emailassistant.data.repository.impl

import com.emailassistant.data.api.MicrosoftGraphApi
import com.emailassistant.data.api.dto.EmailDtoFactory
import com.emailassistant.data.api.dto.OutlookFolders
import com.emailassistant.data.mapper.EmailMapper
import com.emailassistant.data.model.DateRange
import com.emailassistant.data.model.Email
import com.emailassistant.data.repository.EmailRepository
import com.emailassistant.data.storage.AuthTokenManager
import com.emailassistant.data.storage.EmailCacheDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementação do repositório de e-mails usando Microsoft Graph API
 */
@Singleton
class EmailRepositoryImpl @Inject constructor(
    private val api: MicrosoftGraphApi,
    private val mapper: EmailMapper,
    private val authTokenManager: AuthTokenManager,
    private val cacheDao: EmailCacheDao
) : EmailRepository {

    override suspend fun getEmailsByDateRange(dateRange: DateRange): Result<List<Email>> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val filter = buildDateRangeFilter(dateRange)
            val response = api.getMessages(
                authorization = "Bearer $token",
                filter = filter,
                top = 100
            )

            if (response.isSuccessful) {
                val emails = response.body()?.emails?.let { mapper.mapToEmailList(it) } ?: emptyList()
                
                // Cache dos e-mails
                cacheEmails(emails)
                
                Timber.d("Obtidos ${emails.size} e-mails para o período ${dateRange.description}")
                Result.success(emails)
            } else {
                val error = "Erro ao obter e-mails: ${response.code()} - ${response.message()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter e-mails por data")
            Result.failure(e)
        }
    }

    override suspend fun getEmailsBySender(senderAddress: String, dateRange: DateRange?): Result<List<Email>> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val filters = mutableListOf("from/emailAddress/address eq '$senderAddress'")
            dateRange?.let { filters.add(buildDateRangeFilter(it)) }
            
            val filter = filters.joinToString(" and ")
            val response = api.getMessages(
                authorization = "Bearer $token",
                filter = filter,
                top = 100
            )

            if (response.isSuccessful) {
                val emails = response.body()?.emails?.let { mapper.mapToEmailList(it) } ?: emptyList()
                Timber.d("Obtidos ${emails.size} e-mails do remetente $senderAddress")
                Result.success(emails)
            } else {
                val error = "Erro ao obter e-mails por remetente: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter e-mails por remetente")
            Result.failure(e)
        }
    }

    override suspend fun searchEmails(keywords: List<String>, dateRange: DateRange?): Result<List<Email>> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val searchQuery = keywords.joinToString(" OR ")
            val response = api.searchMessages(
                authorization = "Bearer $token",
                search = searchQuery,
                top = 100
            )

            if (response.isSuccessful) {
                var emails = response.body()?.emails?.let { mapper.mapToEmailList(it) } ?: emptyList()
                
                // Filtrar por data se especificado
                dateRange?.let { range ->
                    emails = emails.filter { email ->
                        email.receivedDateTime.after(range.startDate) && 
                        email.receivedDateTime.before(range.endDate)
                    }
                }
                
                Timber.d("Encontrados ${emails.size} e-mails para busca: $searchQuery")
                Result.success(emails)
            } else {
                val error = "Erro na busca de e-mails: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro na busca de e-mails")
            Result.failure(e)
        }
    }

    override suspend fun getEmailById(emailId: String): Result<Email> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val response = api.getMessage(
                authorization = "Bearer $token",
                messageId = emailId
            )

            if (response.isSuccessful) {
                val email = response.body()?.let { mapper.mapToEmail(it) }
                    ?: return Result.failure(Exception("E-mail não encontrado"))
                
                Timber.d("E-mail obtido: ${email.subject}")
                Result.success(email)
            } else {
                val error = "Erro ao obter e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter e-mail por ID")
            Result.failure(e)
        }
    }

    override suspend fun sendEmail(
        recipient: String,
        subject: String,
        body: String,
        replyToEmailId: String?
    ): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val emailRequest = EmailDtoFactory.createSendEmailRequest(
                subject = subject,
                body = body,
                toRecipients = listOf("" to recipient) // Nome vazio, apenas endereço
            )

            val response = api.sendEmail(
                authorization = "Bearer $token",
                emailRequest = emailRequest
            )

            if (response.isSuccessful) {
                Timber.d("E-mail enviado com sucesso para $recipient")
                Result.success(true)
            } else {
                val error = "Erro ao enviar e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao enviar e-mail")
            Result.failure(e)
        }
    }

    override suspend fun replyToEmail(
        emailId: String,
        replyBody: String,
        replyToAll: Boolean
    ): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val replyRequest = EmailDtoFactory.createReplyRequest(replyBody)
            
            val response = if (replyToAll) {
                api.replyToAllEmail(
                    authorization = "Bearer $token",
                    messageId = emailId,
                    replyRequest = replyRequest
                )
            } else {
                api.replyToEmail(
                    authorization = "Bearer $token",
                    messageId = emailId,
                    replyRequest = replyRequest
                )
            }

            if (response.isSuccessful) {
                Timber.d("Resposta enviada com sucesso")
                Result.success(true)
            } else {
                val error = "Erro ao responder e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao responder e-mail")
            Result.failure(e)
        }
    }

    override suspend fun markEmailAsRead(emailId: String, isRead: Boolean): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val updateRequest = mapOf("isRead" to isRead)
            val response = api.updateMessage(
                authorization = "Bearer $token",
                messageId = emailId,
                updateRequest = updateRequest
            )

            if (response.isSuccessful) {
                Timber.d("E-mail marcado como ${if (isRead) "lido" else "não lido"}")
                Result.success(true)
            } else {
                val error = "Erro ao marcar e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao marcar e-mail")
            Result.failure(e)
        }
    }

    override suspend fun archiveEmail(emailId: String): Result<Boolean> {
        return moveEmailToFolder(emailId, OutlookFolders.ARCHIVE)
    }

    override suspend fun deleteEmail(emailId: String): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val response = api.deleteMessage(
                authorization = "Bearer $token",
                messageId = emailId
            )

            if (response.isSuccessful) {
                Timber.d("E-mail excluído com sucesso")
                // Remove do cache
                cacheDao.deleteEmail(emailId)
                Result.success(true)
            } else {
                val error = "Erro ao excluir e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao excluir e-mail")
            Result.failure(e)
        }
    }

    override suspend fun moveEmailToFolder(emailId: String, folderName: String): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            // Primeiro, obter o ID da pasta pelo nome
            val folderId = getFolderIdByName(folderName)
                ?: return Result.failure(Exception("Pasta '$folderName' não encontrada"))

            val moveRequest = mapOf("destinationId" to folderId)
            val response = api.moveMessage(
                authorization = "Bearer $token",
                messageId = emailId,
                moveRequest = moveRequest
            )

            if (response.isSuccessful) {
                Timber.d("E-mail movido para pasta $folderName")
                Result.success(true)
            } else {
                val error = "Erro ao mover e-mail: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao mover e-mail")
            Result.failure(e)
        }
    }

    override suspend fun flagEmail(emailId: String, flagged: Boolean): Result<Boolean> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val flagStatus = if (flagged) "flagged" else "notFlagged"
            val updateRequest = mapOf(
                "flag" to mapOf("flagStatus" to flagStatus)
            )
            
            val response = api.updateMessage(
                authorization = "Bearer $token",
                messageId = emailId,
                updateRequest = updateRequest
            )

            if (response.isSuccessful) {
                Timber.d("E-mail ${if (flagged) "marcado" else "desmarcado"} com flag")
                Result.success(true)
            } else {
                val error = "Erro ao marcar flag: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao marcar flag")
            Result.failure(e)
        }
    }

    override suspend fun getAvailableFolders(): Result<List<String>> {
        return try {
            val token = authTokenManager.getAccessToken()
                ?: return Result.failure(Exception("Token de acesso não disponível"))

            val response = api.getMailFolders(authorization = "Bearer $token")

            if (response.isSuccessful) {
                val folderNames = response.body()?.folders?.map { it.displayName } ?: emptyList()
                Timber.d("Pastas disponíveis: $folderNames")
                Result.success(folderNames)
            } else {
                val error = "Erro ao obter pastas: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter pastas")
            Result.failure(e)
        }
    }

    override fun getCachedEmails(): Flow<List<Email>> {
        return cacheDao.getAllEmails().map { entities ->
            entities.map { mapper.mapToEmail(it) }
        }
    }

    override suspend fun syncEmails(): Result<Boolean> {
        return try {
            // Sincronizar e-mails dos últimos 30 dias
            val thirtyDaysAgo = java.util.Calendar.getInstance().apply {
                add(java.util.Calendar.DAY_OF_MONTH, -30)
            }.time
            
            val dateRange = DateRange(
                startDate = thirtyDaysAgo,
                endDate = java.util.Date(),
                description = "últimos 30 dias"
            )
            
            getEmailsByDateRange(dateRange).fold(
                onSuccess = { 
                    Timber.d("Sincronização concluída com sucesso")
                    Result.success(true) 
                },
                onFailure = { Result.failure(it) }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro na sincronização")
            Result.failure(e)
        }
    }

    override suspend fun isConnected(): Boolean {
        return try {
            authTokenManager.getAccessToken() != null
        } catch (e: Exception) {
            false
        }
    }

    // Métodos auxiliares privados

    private fun buildDateRangeFilter(dateRange: DateRange): String {
        val startDate = mapper.formatDate(dateRange.startDate)
        val endDate = mapper.formatDate(dateRange.endDate)
        return "receivedDateTime ge $startDate and receivedDateTime le $endDate"
    }

    private suspend fun getFolderIdByName(folderName: String): String? {
        return try {
            val token = authTokenManager.getAccessToken() ?: return null
            val filter = "displayName eq '$folderName'"
            
            val response = api.getFolderByName(
                authorization = "Bearer $token",
                filter = filter
            )
            
            if (response.isSuccessful) {
                response.body()?.folders?.firstOrNull()?.id
            } else {
                null
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter ID da pasta $folderName")
            null
        }
    }

    private suspend fun cacheEmails(emails: List<Email>) {
        try {
            // Implementar cache dos e-mails
            // cacheDao.insertEmails(emails.map { mapper.mapToEntity(it) })
        } catch (e: Exception) {
            Timber.e(e, "Erro ao fazer cache dos e-mails")
        }
    }
}

