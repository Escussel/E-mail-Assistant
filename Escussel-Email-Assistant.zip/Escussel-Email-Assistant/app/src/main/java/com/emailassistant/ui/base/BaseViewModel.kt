package com.emailassistant.ui.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Classe base para ViewModels com funcionalidades comuns
 */
abstract class BaseViewModel : ViewModel() {

    // Estado de loading
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Eventos de erro
    private val _errorEvents = MutableSharedFlow<String>()
    val errorEvents: SharedFlow<String> = _errorEvents.asSharedFlow()

    // Eventos de sucesso
    private val _successEvents = MutableSharedFlow<String>()
    val successEvents: SharedFlow<String> = _successEvents.asSharedFlow()

    // Handler para exceções de corrotinas
    protected val exceptionHandler = CoroutineExceptionHandler { _, exception ->
        Timber.e(exception, "Erro não tratado no ViewModel")
        handleError(exception.message ?: "Erro desconhecido")
    }

    /**
     * Executa uma operação com loading e tratamento de erro
     */
    protected fun executeWithLoading(
        showLoading: Boolean = true,
        operation: suspend () -> Unit
    ) {
        viewModelScope.launch(exceptionHandler) {
            try {
                if (showLoading) _isLoading.value = true
                operation()
            } catch (e: Exception) {
                Timber.e(e, "Erro na operação")
                handleError(e.message ?: "Erro na operação")
            } finally {
                if (showLoading) _isLoading.value = false
            }
        }
    }

    /**
     * Trata resultado de operações
     */
    protected fun <T> handleResult(
        result: Result<T>,
        onSuccess: (T) -> Unit,
        onError: ((String) -> Unit)? = null
    ) {
        result.fold(
            onSuccess = onSuccess,
            onFailure = { exception ->
                val errorMessage = exception.message ?: "Erro desconhecido"
                Timber.e(exception, "Erro no resultado: $errorMessage")
                onError?.invoke(errorMessage) ?: handleError(errorMessage)
            }
        )
    }

    /**
     * Emite evento de erro
     */
    protected fun handleError(message: String) {
        viewModelScope.launch {
            _errorEvents.emit(message)
        }
    }

    /**
     * Emite evento de sucesso
     */
    protected fun handleSuccess(message: String) {
        viewModelScope.launch {
            _successEvents.emit(message)
        }
    }

    /**
     * Define estado de loading
     */
    protected fun setLoading(loading: Boolean) {
        _isLoading.value = loading
    }
}

