package com.emailassistant.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

/**
 * Representa um comando de voz processado
 */
@Parcelize
data class VoiceCommand(
    val id: String,
    val rawText: String,
    val processedText: String,
    val intent: CommandIntent,
    val parameters: Map<String, String>,
    val confidence: Float,
    val timestamp: Date
) : Parcelable

@Parcelize
enum class CommandIntent : Parcelable {
    ANALYZE_EMAILS,
    REPLY_EMAIL,
    COMPOSE_EMAIL,
    SEARCH_EMAILS,
    GET_SUMMARY,
    ASK_QUESTION,
    ARCHIVE_EMAIL,
    DELETE_EMAIL,
    MOVE_TO_FOLDER,
    UNKNOWN
}

/**
 * Parâmetros específicos para análise de e-mails
 */
@Parcelize
data class EmailAnalysisParams(
    val dateRange: DateRange,
    val sender: String? = null,
    val subject: String? = null,
    val keywords: List<String> = emptyList()
) : Parcelable

@Parcelize
data class DateRange(
    val startDate: Date,
    val endDate: Date,
    val description: String // "últimos 7 dias", "esta semana", etc.
) : Parcelable

/**
 * Parâmetros para composição de e-mail
 */
@Parcelize
data class EmailCompositionParams(
    val recipient: String? = null,
    val subject: String? = null,
    val content: String,
    val replyToEmailId: String? = null
) : Parcelable

/**
 * Parâmetros para operações de e-mail (arquivar, excluir, mover)
 */
@Parcelize
data class EmailOperationParams(
    val emailId: String,
    val operation: EmailOperation,
    val targetFolder: String? = null // Para operação MOVE_TO_FOLDER
) : Parcelable

@Parcelize
enum class EmailOperation : Parcelable {
    ARCHIVE,
    DELETE,
    MOVE_TO_FOLDER,
    MARK_AS_READ,
    MARK_AS_UNREAD,
    FLAG,
    UNFLAG
}

/**
 * Resultado do processamento de comando de voz
 */
@Parcelize
data class VoiceCommandResult(
    val command: VoiceCommand,
    val success: Boolean,
    val response: String,
    val data: Any? = null,
    val error: String? = null
) : Parcelable

