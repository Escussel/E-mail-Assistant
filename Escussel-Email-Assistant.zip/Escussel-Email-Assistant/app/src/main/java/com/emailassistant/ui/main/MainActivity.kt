package com.emailassistant.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.emailassistant.R
import com.emailassistant.databinding.ActivityMainBinding
import com.emailassistant.ui.auth.AuthActivity
import com.emailassistant.ui.setup.SetupActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Atividade principal do aplicativo
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            initializeApp()
        } else {
            showPermissionDeniedMessage()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()
        setupClickListeners()
        checkPermissionsAndInitialize()
    }

    private fun setupObservers() {
        // Observar estado da configuração
        viewModel.isConfigured.observe(this) { isConfigured ->
            if (!isConfigured) {
                startActivity(Intent(this, SetupActivity::class.java))
                finish()
            }
        }

        // Observar estado de autenticação
        viewModel.isAuthenticated.observe(this) { isAuthenticated ->
            if (!isAuthenticated) {
                startActivity(Intent(this, AuthActivity::class.java))
            }
        }

        // Observar estado do reconhecimento de voz
        viewModel.isListening.observe(this) { isListening ->
            updateVoiceButton(isListening)
        }

        // Observar texto reconhecido
        viewModel.recognizedText.observe(this) { text ->
            binding.tvRecognizedText.text = text
        }

        // Observar resposta da IA
        viewModel.aiResponse.observe(this) { response ->
            binding.tvAiResponse.text = response
        }

        // Observar estado de carregamento
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
        }

        // Observar mensagens de erro
        viewModel.errorMessage.observe(this) { error ->
            if (error.isNotEmpty()) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        }

        // Observar análise de e-mails
        viewModel.emailAnalysis.observe(this) { analysis ->
            analysis?.let {
                updateEmailAnalysisUI(it)
            }
        }
    }

    private fun setupClickListeners() {
        // Botão de voz principal
        binding.btnVoice.setOnClickListener {
            if (viewModel.isListening.value == true) {
                viewModel.stopListening()
            } else {
                viewModel.startListening()
            }
        }

        // Botão de configurações
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }

        // Botão de análise manual
        binding.btnAnalyzeEmails.setOnClickListener {
            viewModel.analyzeRecentEmails()
        }

        // Botão de modo hands-free
        binding.btnHandsFree.setOnClickListener {
            viewModel.toggleHandsFreeMode()
        }

        // Botão para parar síntese de voz
        binding.btnStopSpeaking.setOnClickListener {
            viewModel.stopSpeaking()
        }
    }

    private fun checkPermissionsAndInitialize() {
        val requiredPermissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE
        )

        val missingPermissions = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isEmpty()) {
            initializeApp()
        } else {
            requestPermissionLauncher.launch(missingPermissions.toTypedArray())
        }
    }

    private fun initializeApp() {
        lifecycleScope.launch {
            viewModel.initialize()
        }
    }

    private fun showPermissionDeniedMessage() {
        Toast.makeText(
            this,
            "Permissões necessárias para o funcionamento do aplicativo",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }

    private fun updateVoiceButton(isListening: Boolean) {
        if (isListening) {
            binding.btnVoice.text = "Parar"
            binding.btnVoice.setBackgroundColor(
                ContextCompat.getColor(this, R.color.red_500)
            )
            binding.ivVoiceIndicator.visibility = android.view.View.VISIBLE
        } else {
            binding.btnVoice.text = "Falar"
            binding.btnVoice.setBackgroundColor(
                ContextCompat.getColor(this, R.color.blue_500)
            )
            binding.ivVoiceIndicator.visibility = android.view.View.GONE
        }
    }

    private fun updateEmailAnalysisUI(analysis: com.emailassistant.data.model.EmailAnalysis) {
        binding.tvEmailCount.text = "E-mails analisados: ${analysis.emails.size}"
        binding.tvSummary.text = analysis.summary
        
        // Atualizar lista de tópicos
        val topicsText = analysis.keyTopics.joinToString("\n") { "• $it" }
        binding.tvTopics.text = topicsText
        
        // Atualizar grupos similares
        val similarGroupsText = analysis.similarityGroups.joinToString("\n") { group ->
            "• ${group.commonTheme} (${group.emails.size} e-mails)"
        }
        binding.tvSimilarGroups.text = similarGroupsText
        
        // Atualizar itens acionáveis
        val actionableText = analysis.actionableItems.joinToString("\n") { item ->
            "• ${item.description}"
        }
        binding.tvActionableItems.text = actionableText
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkConfiguration()
    }

    override fun onPause() {
        super.onPause()
        viewModel.stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.cleanup()
    }
}

