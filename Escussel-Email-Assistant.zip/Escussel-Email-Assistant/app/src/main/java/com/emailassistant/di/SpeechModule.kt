package com.emailassistant.di

import android.content.Context
import com.emailassistant.data.speech.SpeechRecognitionService
import com.emailassistant.data.speech.TextToSpeechService
import com.emailassistant.data.speech.VoiceCommandProcessor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo Hilt para serviços de voz
 */
@Module
@InstallIn(SingletonComponent::class)
object SpeechModule {

    @Provides
    @Singleton
    fun provideSpeechRecognitionService(
        @ApplicationContext context: Context
    ): SpeechRecognitionService {
        return SpeechRecognitionService(context)
    }

    @Provides
    @Singleton
    fun provideTextToSpeechService(
        @ApplicationContext context: Context
    ): TextToSpeechService {
        return TextToSpeechService(context)
    }

    @Provides
    @Singleton
    fun provideVoiceCommandProcessor(): VoiceCommandProcessor {
        return VoiceCommandProcessor()
    }
}

