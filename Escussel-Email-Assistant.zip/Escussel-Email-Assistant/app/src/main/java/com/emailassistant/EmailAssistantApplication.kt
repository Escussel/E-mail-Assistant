package com.emailassistant

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * Classe Application principal do Email Assistant
 * Configurada com Hilt para injeção de dependência
 */
@HiltAndroidApp
class EmailAssistantApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        
        // Configurar Timber para logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        
        Timber.d("EmailAssistantApplication iniciado")
    }
}

