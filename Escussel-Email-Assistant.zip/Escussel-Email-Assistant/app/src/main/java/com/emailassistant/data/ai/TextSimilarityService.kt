package com.emailassistant.data.ai

import com.emailassistant.data.model.Email
import com.emailassistant.data.model.SimilarityGroup
import timber.log.Timber
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.*

/**
 * Serviço para análise de similaridade entre textos e e-mails
 */
@Singleton
class TextSimilarityService @Inject constructor(
    private val openAIService: OpenAIService
) {

    companion object {
        private const val SIMILARITY_THRESHOLD = 0.7f
        private const val MIN_GROUP_SIZE = 2
    }

    /**
     * Calcula similaridade entre dois textos usando cosseno
     */
    suspend fun calculateCosineSimilarity(
        text1: String,
        text2: String,
        apiKey: String
    ): Result<Float> {
        return try {
            val embeddings = openAIService.generateEmbeddings(
                texts = listOf(text1, text2),
                apiKey = apiKey
            )

            embeddings.fold(
                onSuccess = { embeddingsList ->
                    if (embeddingsList.size >= 2) {
                        val similarity = cosineSimilarity(embeddingsList[0], embeddingsList[1])
                        Result.success(similarity)
                    } else {
                        Result.failure(Exception("Embeddings insuficientes"))
                    }
                },
                onFailure = { exception ->
                    // Fallback para similaridade baseada em palavras-chave
                    Timber.w("Usando fallback para similaridade: ${exception.message}")
                    val similarity = calculateKeywordSimilarity(text1, text2)
                    Result.success(similarity)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao calcular similaridade")
            Result.failure(e)
        }
    }

    /**
     * Encontra grupos de e-mails similares
     */
    suspend fun findSimilarEmailGroups(
        emails: List<Email>,
        apiKey: String
    ): Result<List<SimilarityGroup>> {
        return try {
            if (emails.size < MIN_GROUP_SIZE) {
                return Result.success(emptyList())
            }

            // Extrair textos para análise (assunto + preview do corpo)
            val emailTexts = emails.map { "${it.subject} ${it.bodyPreview}" }
            
            // Gerar embeddings para todos os e-mails
            val embeddingsResult = openAIService.generateEmbeddings(emailTexts, apiKey)
            
            embeddingsResult.fold(
                onSuccess = { embeddings ->
                    val groups = clusterEmailsBySimilarity(emails, embeddings)
                    Result.success(groups)
                },
                onFailure = { exception ->
                    Timber.w("Usando fallback para agrupamento: ${exception.message}")
                    val groups = clusterEmailsByKeywords(emails)
                    Result.success(groups)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao encontrar grupos similares")
            Result.failure(e)
        }
    }

    /**
     * Encontra e-mails similares a um e-mail específico
     */
    suspend fun findSimilarEmails(
        targetEmail: Email,
        allEmails: List<Email>,
        apiKey: String,
        maxResults: Int = 5
    ): Result<List<Email>> {
        return try {
            val targetText = "${targetEmail.subject} ${targetEmail.bodyPreview}"
            val otherEmails = allEmails.filter { it.id != targetEmail.id }
            
            if (otherEmails.isEmpty()) {
                return Result.success(emptyList())
            }

            val similarities = mutableListOf<Pair<Email, Float>>()
            
            for (email in otherEmails) {
                val emailText = "${email.subject} ${email.bodyPreview}"
                val similarityResult = calculateCosineSimilarity(targetText, emailText, apiKey)
                
                similarityResult.fold(
                    onSuccess = { similarity ->
                        if (similarity >= SIMILARITY_THRESHOLD) {
                            similarities.add(email to similarity)
                        }
                    },
                    onFailure = { 
                        Timber.w("Erro ao calcular similaridade para e-mail ${email.id}")
                    }
                )
            }

            // Ordenar por similaridade e retornar os mais similares
            val similarEmails = similarities
                .sortedByDescending { it.second }
                .take(maxResults)
                .map { it.first }

            Timber.d("Encontrados ${similarEmails.size} e-mails similares")
            Result.success(similarEmails)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao encontrar e-mails similares")
            Result.failure(e)
        }
    }

    /**
     * Extrai tópicos principais de uma lista de e-mails
     */
    suspend fun extractTopics(
        emails: List<Email>,
        apiKey: String
    ): Result<List<String>> {
        return try {
            val emailTexts = emails.map { "${it.subject} ${it.bodyPreview}" }
            
            val analysisResult = openAIService.analyzeEmails(
                emails = emailTexts,
                analysisType = "topics",
                apiKey = apiKey
            )

            analysisResult.fold(
                onSuccess = { topicsText ->
                    val topics = parseTopicsFromText(topicsText)
                    Result.success(topics)
                },
                onFailure = { exception ->
                    Timber.w("Usando fallback para extração de tópicos: ${exception.message}")
                    val topics = extractTopicsKeywordBased(emails)
                    Result.success(topics)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao extrair tópicos")
            Result.failure(e)
        }
    }

    // Métodos auxiliares privados

    private fun cosineSimilarity(vector1: List<Double>, vector2: List<Double>): Float {
        if (vector1.size != vector2.size) return 0f

        var dotProduct = 0.0
        var norm1 = 0.0
        var norm2 = 0.0

        for (i in vector1.indices) {
            dotProduct += vector1[i] * vector2[i]
            norm1 += vector1[i] * vector1[i]
            norm2 += vector2[i] * vector2[i]
        }

        return if (norm1 == 0.0 || norm2 == 0.0) {
            0f
        } else {
            (dotProduct / (sqrt(norm1) * sqrt(norm2))).toFloat()
        }
    }

    private fun calculateKeywordSimilarity(text1: String, text2: String): Float {
        val words1 = extractKeywords(text1)
        val words2 = extractKeywords(text2)
        
        if (words1.isEmpty() || words2.isEmpty()) return 0f
        
        val intersection = words1.intersect(words2).size
        val union = words1.union(words2).size
        
        return if (union == 0) 0f else intersection.toFloat() / union.toFloat()
    }

    private fun extractKeywords(text: String): Set<String> {
        val stopWords = setOf(
            "o", "a", "os", "as", "de", "da", "do", "das", "dos", "em", "na", "no", "nas", "nos",
            "para", "por", "com", "sem", "sobre", "entre", "até", "desde", "durante", "através",
            "e", "ou", "mas", "que", "se", "quando", "onde", "como", "por", "porque",
            "email", "e-mail", "emails", "e-mails", "mensagem", "mensagens", "assunto"
        )

        return text.lowercase()
            .replace(Regex("[^a-záàâãéèêíìîóòôõúùûç\\s]"), "")
            .split("\\s+".toRegex())
            .filter { it.length > 2 && !stopWords.contains(it) }
            .toSet()
    }

    private fun clusterEmailsBySimilarity(
        emails: List<Email>,
        embeddings: List<List<Double>>
    ): List<SimilarityGroup> {
        val groups = mutableListOf<SimilarityGroup>()
        val processed = mutableSetOf<Int>()

        for (i in emails.indices) {
            if (processed.contains(i)) continue

            val similarEmails = mutableListOf<Email>()
            similarEmails.add(emails[i])
            processed.add(i)

            for (j in i + 1 until emails.size) {
                if (processed.contains(j)) continue

                val similarity = cosineSimilarity(embeddings[i], embeddings[j])
                if (similarity >= SIMILARITY_THRESHOLD) {
                    similarEmails.add(emails[j])
                    processed.add(j)
                }
            }

            if (similarEmails.size >= MIN_GROUP_SIZE) {
                val commonTheme = extractCommonTheme(similarEmails)
                val avgSimilarity = calculateAverageSimilarity(similarEmails, embeddings, emails)
                
                groups.add(
                    SimilarityGroup(
                        id = UUID.randomUUID().toString(),
                        emails = similarEmails,
                        commonTheme = commonTheme,
                        similarityScore = avgSimilarity
                    )
                )
            }
        }

        return groups
    }

    private fun clusterEmailsByKeywords(emails: List<Email>): List<SimilarityGroup> {
        val groups = mutableListOf<SimilarityGroup>()
        val processed = mutableSetOf<String>()

        for (email in emails) {
            if (processed.contains(email.id)) continue

            val emailKeywords = extractKeywords("${email.subject} ${email.bodyPreview}")
            val similarEmails = mutableListOf<Email>()
            similarEmails.add(email)
            processed.add(email.id)

            for (otherEmail in emails) {
                if (processed.contains(otherEmail.id)) continue

                val otherKeywords = extractKeywords("${otherEmail.subject} ${otherEmail.bodyPreview}")
                val similarity = calculateKeywordSimilarity(
                    emailKeywords.joinToString(" "),
                    otherKeywords.joinToString(" ")
                )

                if (similarity >= SIMILARITY_THRESHOLD) {
                    similarEmails.add(otherEmail)
                    processed.add(otherEmail.id)
                }
            }

            if (similarEmails.size >= MIN_GROUP_SIZE) {
                val commonTheme = extractCommonTheme(similarEmails)
                
                groups.add(
                    SimilarityGroup(
                        id = UUID.randomUUID().toString(),
                        emails = similarEmails,
                        commonTheme = commonTheme,
                        similarityScore = SIMILARITY_THRESHOLD
                    )
                )
            }
        }

        return groups
    }

    private fun extractCommonTheme(emails: List<Email>): String {
        val allKeywords = emails.flatMap { email ->
            extractKeywords("${email.subject} ${email.bodyPreview}")
        }

        val keywordFrequency = allKeywords.groupingBy { it }.eachCount()
        val commonKeywords = keywordFrequency
            .filter { it.value >= 2 }
            .toList()
            .sortedByDescending { it.second }
            .take(3)
            .map { it.first }

        return if (commonKeywords.isNotEmpty()) {
            commonKeywords.joinToString(", ")
        } else {
            "Tópico comum"
        }
    }

    private fun calculateAverageSimilarity(
        similarEmails: List<Email>,
        embeddings: List<List<Double>>,
        allEmails: List<Email>
    ): Float {
        if (similarEmails.size < 2) return 1.0f

        var totalSimilarity = 0f
        var comparisons = 0

        for (i in similarEmails.indices) {
            for (j in i + 1 until similarEmails.size) {
                val index1 = allEmails.indexOfFirst { it.id == similarEmails[i].id }
                val index2 = allEmails.indexOfFirst { it.id == similarEmails[j].id }
                
                if (index1 >= 0 && index2 >= 0 && index1 < embeddings.size && index2 < embeddings.size) {
                    totalSimilarity += cosineSimilarity(embeddings[index1], embeddings[index2])
                    comparisons++
                }
            }
        }

        return if (comparisons > 0) totalSimilarity / comparisons else 1.0f
    }

    private fun parseTopicsFromText(topicsText: String): List<String> {
        return topicsText.split("\n")
            .filter { it.trim().isNotEmpty() }
            .map { it.replace(Regex("^[-*•]\\s*"), "").trim() }
            .filter { it.isNotEmpty() }
            .take(10)
    }

    private fun extractTopicsKeywordBased(emails: List<Email>): List<String> {
        val allKeywords = emails.flatMap { email ->
            extractKeywords("${email.subject} ${email.bodyPreview}")
        }

        return allKeywords
            .groupingBy { it }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(10)
            .map { it.first }
    }
}

