package com.emailassistant.data.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gerenciador de tokens de autenticação OAuth 2.0
 */
@Singleton
class AuthTokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            "auth_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_TOKEN_EXPIRY = "token_expiry"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_IS_AUTHENTICATED = "is_authenticated"
    }

    /**
     * Salva tokens de autenticação
     */
    suspend fun saveTokens(
        accessToken: String,
        refreshToken: String?,
        expiresInSeconds: Long,
        userEmail: String? = null,
        userName: String? = null
    ) = withContext(Dispatchers.IO) {
        try {
            val expiryTime = System.currentTimeMillis() + (expiresInSeconds * 1000)
            
            encryptedPrefs.edit().apply {
                putString(KEY_ACCESS_TOKEN, accessToken)
                refreshToken?.let { putString(KEY_REFRESH_TOKEN, it) }
                putLong(KEY_TOKEN_EXPIRY, expiryTime)
                userEmail?.let { putString(KEY_USER_EMAIL, it) }
                userName?.let { putString(KEY_USER_NAME, it) }
                putBoolean(KEY_IS_AUTHENTICATED, true)
                apply()
            }
            
            Timber.d("Tokens salvos com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao salvar tokens")
            throw e
        }
    }

    /**
     * Obtém token de acesso válido
     */
    suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        try {
            if (!isTokenValid()) {
                Timber.d("Token expirado, tentando renovar")
                if (!refreshAccessToken()) {
                    return@withContext null
                }
            }
            
            encryptedPrefs.getString(KEY_ACCESS_TOKEN, null)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao obter token de acesso")
            null
        }
    }

    /**
     * Obtém token de refresh
     */
    suspend fun getRefreshToken(): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString(KEY_REFRESH_TOKEN, null)
    }

    /**
     * Verifica se o token é válido
     */
    private fun isTokenValid(): Boolean {
        val expiryTime = encryptedPrefs.getLong(KEY_TOKEN_EXPIRY, 0)
        val currentTime = System.currentTimeMillis()
        val bufferTime = 5 * 60 * 1000 // 5 minutos de buffer
        
        return expiryTime > (currentTime + bufferTime)
    }

    /**
     * Renova o token de acesso usando refresh token
     */
    private suspend fun refreshAccessToken(): Boolean = withContext(Dispatchers.IO) {
        try {
            val refreshToken = getRefreshToken()
            if (refreshToken == null) {
                Timber.w("Refresh token não disponível")
                return@withContext false
            }

            // TODO: Implementar chamada para renovar token
            // Por enquanto, retorna false para forçar nova autenticação
            Timber.d("Renovação de token não implementada ainda")
            false
        } catch (e: Exception) {
            Timber.e(e, "Erro ao renovar token")
            false
        }
    }

    /**
     * Verifica se o usuário está autenticado
     */
    fun isAuthenticated(): Boolean {
        return encryptedPrefs.getBoolean(KEY_IS_AUTHENTICATED, false) && 
               encryptedPrefs.getString(KEY_ACCESS_TOKEN, null) != null
    }

    /**
     * Obtém e-mail do usuário autenticado
     */
    fun getUserEmail(): String? {
        return encryptedPrefs.getString(KEY_USER_EMAIL, null)
    }

    /**
     * Obtém nome do usuário autenticado
     */
    fun getUserName(): String? {
        return encryptedPrefs.getString(KEY_USER_NAME, null)
    }

    /**
     * Limpa todos os dados de autenticação
     */
    suspend fun clearAuthData() = withContext(Dispatchers.IO) {
        try {
            encryptedPrefs.edit().clear().apply()
            Timber.d("Dados de autenticação limpos")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao limpar dados de autenticação")
        }
    }

    /**
     * Obtém tempo restante do token em segundos
     */
    fun getTokenTimeRemaining(): Long {
        val expiryTime = encryptedPrefs.getLong(KEY_TOKEN_EXPIRY, 0)
        val currentTime = System.currentTimeMillis()
        return maxOf(0, (expiryTime - currentTime) / 1000)
    }

    /**
     * Verifica se precisa renovar o token
     */
    fun needsTokenRefresh(): Boolean {
        val timeRemaining = getTokenTimeRemaining()
        return timeRemaining < (10 * 60) // Menos de 10 minutos
    }
}

