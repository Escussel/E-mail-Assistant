package com.emailassistant.data.repository

import com.emailassistant.data.model.VoiceCommand
import com.emailassistant.data.model.VoiceCommandResult
import kotlinx.coroutines.flow.Flow

/**
 * Interface do repositório para reconhecimento e síntese de voz
 */
interface SpeechRepository {
    
    /**
     * Inicia o reconhecimento de voz
     */
    suspend fun startListening(): Result<Boolean>
    
    /**
     * Para o reconhecimento de voz
     */
    suspend fun stopListening(): Result<Boolean>
    
    /**
     * Obtém o texto reconhecido como Flow
     */
    fun getRecognizedText(): Flow<String>
    
    /**
     * Processa comando de voz e extrai intenção
     */
    suspend fun processVoiceCommand(recognizedText: String): Result<VoiceCommand>
    
    /**
     * Executa comando de voz processado
     */
    suspend fun executeVoiceCommand(command: VoiceCommand): Result<VoiceCommandResult>
    
    /**
     * Converte texto em fala
     */
    suspend fun speakText(text: String): Result<Boolean>
    
    /**
     * Para a síntese de voz
     */
    suspend fun stopSpeaking(): Result<Boolean>
    
    /**
     * Verifica se está falando
     */
    fun isSpeaking(): Boolean
    
    /**
     * Verifica se está ouvindo
     */
    fun isListening(): Boolean
    
    /**
     * Configura idioma para reconhecimento
     */
    suspend fun setLanguage(languageCode: String): Result<Boolean>
    
    /**
     * Obtém idiomas disponíveis
     */
    suspend fun getAvailableLanguages(): Result<List<String>>
    
    /**
     * Configura velocidade da fala
     */
    suspend fun setSpeechRate(rate: Float): Result<Boolean>
    
    /**
     * Configura tom da voz
     */
    suspend fun setPitch(pitch: Float): Result<Boolean>
}

