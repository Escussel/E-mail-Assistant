package com.emailassistant.data.api.dto

import com.google.gson.annotations.SerializedName

/**
 * DTO para resposta de lista de pastas do Microsoft Graph
 */
data class FolderListResponse(
    @SerializedName("@odata.context")
    val context: String,
    @SerializedName("value")
    val folders: List<FolderDto>
)

/**
 * DTO para pasta de e-mail do Microsoft Graph
 */
data class FolderDto(
    @SerializedName("id")
    val id: String,
    @SerializedName("displayName")
    val displayName: String,
    @SerializedName("parentFolderId")
    val parentFolderId: String? = null,
    @SerializedName("childFolderCount")
    val childFolderCount: Int = 0,
    @SerializedName("unreadItemCount")
    val unreadItemCount: Int = 0,
    @SerializedName("totalItemCount")
    val totalItemCount: Int = 0
)

/**
 * Constantes para nomes de pastas padrão do Outlook
 */
object OutlookFolders {
    const val INBOX = "Inbox"
    const val SENT_ITEMS = "SentItems"
    const val DRAFTS = "Drafts"
    const val DELETED_ITEMS = "DeletedItems"
    const val ARCHIVE = "Archive"
    const val JUNK_EMAIL = "JunkEmail"
    const val OUTBOX = "Outbox"
    
    /**
     * Lista de pastas padrão do Outlook
     */
    val DEFAULT_FOLDERS = listOf(
        INBOX,
        SENT_ITEMS,
        DRAFTS,
        DELETED_ITEMS,
        ARCHIVE,
        JUNK_EMAIL,
        OUTBOX
    )
}

