package com.emailassistant.data.api.dto

import com.google.gson.annotations.SerializedName

/**
 * DTO para resposta de lista de e-mails do Microsoft Graph
 */
data class EmailListResponse(
    @SerializedName("@odata.context")
    val context: String,
    @SerializedName("@odata.nextLink")
    val nextLink: String? = null,
    @SerializedName("value")
    val emails: List<EmailDto>
)

/**
 * DTO para e-mail do Microsoft Graph
 */
data class EmailDto(
    @SerializedName("id")
    val id: String,
    @SerializedName("subject")
    val subject: String,
    @SerializedName("sender")
    val sender: EmailAddressDto,
    @SerializedName("toRecipients")
    val toRecipients: List<EmailAddressDto>,
    @SerializedName("ccRecipients")
    val ccRecipients: List<EmailAddressDto>? = null,
    @SerializedName("bccRecipients")
    val bccRecipients: List<EmailAddressDto>? = null,
    @SerializedName("body")
    val body: EmailBodyDto,
    @SerializedName("bodyPreview")
    val bodyPreview: String,
    @SerializedName("receivedDateTime")
    val receivedDateTime: String,
    @SerializedName("isRead")
    val isRead: Boolean,
    @SerializedName("importance")
    val importance: String, // Low, Normal, High
    @SerializedName("hasAttachments")
    val hasAttachments: Boolean,
    @SerializedName("conversationId")
    val conversationId: String,
    @SerializedName("categories")
    val categories: List<String>? = null,
    @SerializedName("flag")
    val flag: EmailFlagDto? = null
)

/**
 * DTO para endereço de e-mail
 */
data class EmailAddressDto(
    @SerializedName("emailAddress")
    val emailAddress: EmailAddressInfoDto
)

data class EmailAddressInfoDto(
    @SerializedName("name")
    val name: String,
    @SerializedName("address")
    val address: String
)

/**
 * DTO para corpo do e-mail
 */
data class EmailBodyDto(
    @SerializedName("contentType")
    val contentType: String, // Text, HTML
    @SerializedName("content")
    val content: String
)

/**
 * DTO para flag do e-mail
 */
data class EmailFlagDto(
    @SerializedName("flagStatus")
    val flagStatus: String, // notFlagged, complete, flagged
    @SerializedName("dueDateTime")
    val dueDateTime: DateTimeDto? = null
)

/**
 * DTO para data/hora
 */
data class DateTimeDto(
    @SerializedName("dateTime")
    val dateTime: String,
    @SerializedName("timeZone")
    val timeZone: String
)

