package com.emailassistant.di

import android.content.Context
import com.emailassistant.data.storage.EmailCacheDao
import com.emailassistant.data.storage.EmailDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo Hilt para configuração do database
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideEmailDatabase(
        @ApplicationContext context: Context
    ): EmailDatabase {
        return EmailDatabase.create(context)
    }

    @Provides
    fun provideEmailCacheDao(
        database: EmailDatabase
    ): EmailCacheDao {
        return database.emailCacheDao()
    }
}

