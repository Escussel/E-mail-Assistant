package com.emailassistant.di

import com.emailassistant.data.ai.OpenAIApi
import com.emailassistant.data.ai.OpenAIService
import com.emailassistant.data.ai.TextSimilarityService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo Hilt para serviços de IA
 */
@Module
@InstallIn(SingletonComponent::class)
object AIModule {

    @Provides
    @Singleton
    fun provideOpenAIService(
        api: OpenAIApi
    ): OpenAIService {
        return OpenAIService(api)
    }

    @Provides
    @Singleton
    fun provideTextSimilarityService(
        openAIService: OpenAIService
    ): TextSimilarityService {
        return TextSimilarityService(openAIService)
    }
}

