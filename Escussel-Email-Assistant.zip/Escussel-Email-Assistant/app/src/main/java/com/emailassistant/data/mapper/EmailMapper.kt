package com.emailassistant.data.mapper

import com.emailassistant.data.api.dto.EmailDto
import com.emailassistant.data.api.dto.EmailAddressDto
import com.emailassistant.data.api.dto.EmailFlagDto
import com.emailassistant.data.model.Email
import com.emailassistant.data.model.EmailAddress
import com.emailassistant.data.model.EmailFlag
import com.emailassistant.data.model.EmailImportance
import com.emailassistant.data.model.FlagStatus
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Mapper para converter DTOs da API em modelos de domínio
 */
@Singleton
class EmailMapper @Inject constructor() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    /**
     * Converte EmailDto em Email
     */
    fun mapToEmail(dto: EmailDto): Email {
        return Email(
            id = dto.id,
            subject = dto.subject,
            sender = mapToEmailAddress(dto.sender),
            recipients = dto.toRecipients.map { mapToEmailAddress(it) },
            body = dto.body.content,
            bodyPreview = dto.bodyPreview,
            receivedDateTime = parseDate(dto.receivedDateTime),
            isRead = dto.isRead,
            importance = mapToEmailImportance(dto.importance),
            hasAttachments = dto.hasAttachments,
            conversationId = dto.conversationId,
            categories = dto.categories ?: emptyList(),
            flag = dto.flag?.let { mapToEmailFlag(it) }
        )
    }

    /**
     * Converte lista de EmailDto em lista de Email
     */
    fun mapToEmailList(dtos: List<EmailDto>): List<Email> {
        return dtos.map { mapToEmail(it) }
    }

    /**
     * Converte EmailAddressDto em EmailAddress
     */
    private fun mapToEmailAddress(dto: EmailAddressDto): EmailAddress {
        return EmailAddress(
            name = dto.emailAddress.name,
            address = dto.emailAddress.address
        )
    }

    /**
     * Converte string de importância em EmailImportance
     */
    private fun mapToEmailImportance(importance: String): EmailImportance {
        return when (importance.lowercase()) {
            "low" -> EmailImportance.LOW
            "high" -> EmailImportance.HIGH
            else -> EmailImportance.NORMAL
        }
    }

    /**
     * Converte EmailFlagDto em EmailFlag
     */
    private fun mapToEmailFlag(dto: EmailFlagDto): EmailFlag {
        return EmailFlag(
            status = mapToFlagStatus(dto.flagStatus),
            dueDateTime = dto.dueDateTime?.let { parseDate(it.dateTime) }
        )
    }

    /**
     * Converte string de status da flag em FlagStatus
     */
    private fun mapToFlagStatus(status: String): FlagStatus {
        return when (status.lowercase()) {
            "complete" -> FlagStatus.COMPLETE
            "flagged" -> FlagStatus.FLAGGED
            else -> FlagStatus.NOT_FLAGGED
        }
    }

    /**
     * Converte string de data ISO 8601 em Date
     */
    private fun parseDate(dateString: String): Date {
        return try {
            dateFormat.parse(dateString) ?: Date()
        } catch (e: Exception) {
            // Fallback para formato alternativo
            try {
                val alternativeFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                alternativeFormat.timeZone = TimeZone.getTimeZone("UTC")
                alternativeFormat.parse(dateString) ?: Date()
            } catch (e2: Exception) {
                Date() // Fallback para data atual
            }
        }
    }

    /**
     * Converte Date em string ISO 8601
     */
    fun formatDate(date: Date): String {
        return dateFormat.format(date)
    }

    /**
     * Converte EmailImportance em string para API
     */
    fun mapFromEmailImportance(importance: EmailImportance): String {
        return when (importance) {
            EmailImportance.LOW -> "low"
            EmailImportance.HIGH -> "high"
            EmailImportance.NORMAL -> "normal"
        }
    }

    /**
     * Converte FlagStatus em string para API
     */
    fun mapFromFlagStatus(status: FlagStatus): String {
        return when (status) {
            FlagStatus.COMPLETE -> "complete"
            FlagStatus.FLAGGED -> "flagged"
            FlagStatus.NOT_FLAGGED -> "notFlagged"
        }
    }
}

