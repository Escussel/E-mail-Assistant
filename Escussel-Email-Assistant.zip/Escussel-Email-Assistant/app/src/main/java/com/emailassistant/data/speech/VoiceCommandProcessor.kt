package com.emailassistant.data.speech

import com.emailassistant.data.model.*
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Processador de comandos de voz para extrair intenções e parâmetros
 */
@Singleton
class VoiceCommandProcessor @Inject constructor() {

    companion object {
        // Padrões para análise de e-mails
        private val ANALYZE_PATTERNS = listOf(
            "analise? os? e-?mails?",
            "verificar? e-?mails?",
            "mostrar? e-?mails?",
            "listar? e-?mails?",
            "ver e-?mails?"
        )

        // Padrões para resposta
        private val REPLY_PATTERNS = listOf(
            "responder?",
            "resposta",
            "reply",
            "enviar? resposta"
        )

        // Padrões para composição
        private val COMPOSE_PATTERNS = listOf(
            "enviar? e-?mail",
            "compor e-?mail",
            "escrever? e-?mail",
            "novo e-?mail"
        )

        // Padrões para arquivamento
        private val ARCHIVE_PATTERNS = listOf(
            "arquivar?",
            "enviar? para arquivo",
            "mover? para arquivo",
            "arquivo"
        )

        // Padrões para exclusão
        private val DELETE_PATTERNS = listOf(
            "excluir?",
            "apagar?",
            "deletar?",
            "remover?"
        )

        // Padrões para busca
        private val SEARCH_PATTERNS = listOf(
            "buscar?",
            "procurar?",
            "encontrar?",
            "pesquisar?"
        )

        // Padrões para perguntas
        private val QUESTION_PATTERNS = listOf(
            "o que",
            "qual",
            "como",
            "quando",
            "onde",
            "por que",
            "quantos?"
        )

        // Padrões de tempo
        private val TIME_PATTERNS = mapOf(
            "hoje" to 0,
            "ontem" to 1,
            "últimos? (\\d+) dias?" to null,
            "última semana" to 7,
            "esta semana" to null,
            "último mês" to 30,
            "este mês" to null,
            "últimos? (\\d+) meses?" to null
        )
    }

    /**
     * Processa texto reconhecido e extrai comando de voz
     */
    fun processCommand(recognizedText: String): VoiceCommand {
        val cleanText = recognizedText.lowercase().trim()
        val commandId = UUID.randomUUID().toString()
        val timestamp = Date()

        Timber.d("Processando comando: $cleanText")

        // Detectar intenção
        val intent = detectIntent(cleanText)
        
        // Extrair parâmetros baseado na intenção
        val parameters = extractParameters(cleanText, intent)
        
        // Calcular confiança baseado na clareza do comando
        val confidence = calculateConfidence(cleanText, intent)

        return VoiceCommand(
            id = commandId,
            rawText = recognizedText,
            processedText = cleanText,
            intent = intent,
            parameters = parameters,
            confidence = confidence,
            timestamp = timestamp
        )
    }

    /**
     * Detecta a intenção do comando
     */
    private fun detectIntent(text: String): CommandIntent {
        return when {
            matchesPatterns(text, ANALYZE_PATTERNS) -> CommandIntent.ANALYZE_EMAILS
            matchesPatterns(text, REPLY_PATTERNS) -> CommandIntent.REPLY_EMAIL
            matchesPatterns(text, COMPOSE_PATTERNS) -> CommandIntent.COMPOSE_EMAIL
            matchesPatterns(text, ARCHIVE_PATTERNS) -> CommandIntent.ARCHIVE_EMAIL
            matchesPatterns(text, DELETE_PATTERNS) -> CommandIntent.DELETE_EMAIL
            matchesPatterns(text, SEARCH_PATTERNS) -> CommandIntent.SEARCH_EMAILS
            matchesPatterns(text, QUESTION_PATTERNS) -> CommandIntent.ASK_QUESTION
            else -> CommandIntent.UNKNOWN
        }
    }

    /**
     * Extrai parâmetros do comando baseado na intenção
     */
    private fun extractParameters(text: String, intent: CommandIntent): Map<String, String> {
        val parameters = mutableMapOf<String, String>()

        when (intent) {
            CommandIntent.ANALYZE_EMAILS -> {
                extractDateRange(text)?.let { dateRange ->
                    parameters["startDate"] = dateRange.startDate.time.toString()
                    parameters["endDate"] = dateRange.endDate.time.toString()
                    parameters["dateDescription"] = dateRange.description
                }
                extractSender(text)?.let { parameters["sender"] = it }
                extractKeywords(text).let { if (it.isNotEmpty()) parameters["keywords"] = it.joinToString(",") }
            }

            CommandIntent.REPLY_EMAIL, CommandIntent.COMPOSE_EMAIL -> {
                extractRecipient(text)?.let { parameters["recipient"] = it }
                extractSubject(text)?.let { parameters["subject"] = it }
                extractContent(text)?.let { parameters["content"] = it }
            }

            CommandIntent.ARCHIVE_EMAIL, CommandIntent.DELETE_EMAIL -> {
                extractEmailReference(text)?.let { parameters["emailReference"] = it }
            }

            CommandIntent.SEARCH_EMAILS -> {
                extractKeywords(text).let { if (it.isNotEmpty()) parameters["keywords"] = it.joinToString(",") }
                extractDateRange(text)?.let { dateRange ->
                    parameters["startDate"] = dateRange.startDate.time.toString()
                    parameters["endDate"] = dateRange.endDate.time.toString()
                }
            }

            CommandIntent.ASK_QUESTION -> {
                parameters["question"] = text
            }

            else -> {
                // Comando desconhecido, salvar texto original
                parameters["originalText"] = text
            }
        }

        return parameters
    }

    /**
     * Extrai range de datas do texto
     */
    private fun extractDateRange(text: String): DateRange? {
        val calendar = Calendar.getInstance()
        val today = calendar.time
        
        return when {
            text.contains("hoje") -> {
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                val startOfDay = calendar.time
                DateRange(startOfDay, today, "hoje")
            }

            text.contains("ontem") -> {
                calendar.add(Calendar.DAY_OF_MONTH, -1)
                val yesterday = calendar.time
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                val startOfYesterday = calendar.time
                DateRange(startOfYesterday, yesterday, "ontem")
            }

            text.contains(Regex("últimos? (\\d+) dias?")) -> {
                val match = Regex("últimos? (\\d+) dias?").find(text)
                val days = match?.groupValues?.get(1)?.toIntOrNull() ?: 7
                calendar.add(Calendar.DAY_OF_MONTH, -days)
                DateRange(calendar.time, today, "últimos $days dias")
            }

            text.contains("última semana") || text.contains("esta semana") -> {
                calendar.add(Calendar.DAY_OF_MONTH, -7)
                DateRange(calendar.time, today, "última semana")
            }

            text.contains("último mês") || text.contains("este mês") -> {
                calendar.add(Calendar.MONTH, -1)
                DateRange(calendar.time, today, "último mês")
            }

            else -> {
                // Padrão: últimos 7 dias
                calendar.add(Calendar.DAY_OF_MONTH, -7)
                DateRange(calendar.time, today, "últimos 7 dias")
            }
        }
    }

    /**
     * Extrai remetente do texto
     */
    private fun extractSender(text: String): String? {
        val patterns = listOf(
            "de (.+?)(?:\\s|$)",
            "do (.+?)(?:\\s|$)",
            "da (.+?)(?:\\s|$)",
            "remetente (.+?)(?:\\s|$)"
        )

        for (pattern in patterns) {
            val match = Regex(pattern).find(text)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    /**
     * Extrai destinatário do texto
     */
    private fun extractRecipient(text: String): String? {
        val patterns = listOf(
            "para (.+?)(?:\\s|$)",
            "ao (.+?)(?:\\s|$)",
            "à (.+?)(?:\\s|$)"
        )

        for (pattern in patterns) {
            val match = Regex(pattern).find(text)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    /**
     * Extrai assunto do texto
     */
    private fun extractSubject(text: String): String? {
        val patterns = listOf(
            "assunto (.+?)(?:\\s|$)",
            "sobre (.+?)(?:\\s|$)",
            "título (.+?)(?:\\s|$)"
        )

        for (pattern in patterns) {
            val match = Regex(pattern).find(text)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    /**
     * Extrai conteúdo do texto
     */
    private fun extractContent(text: String): String? {
        val patterns = listOf(
            "dizendo (.+)",
            "falando (.+)",
            "escrevendo (.+)",
            "conteúdo (.+)"
        )

        for (pattern in patterns) {
            val match = Regex(pattern).find(text)
            if (match != null) {
                return match.groupValues[1].trim()
            }
        }
        return null
    }

    /**
     * Extrai referência a e-mail específico
     */
    private fun extractEmailReference(text: String): String? {
        val patterns = listOf(
            "este e-?mail",
            "esse e-?mail",
            "o e-?mail",
            "e-?mail (.+?)(?:\\s|$)"
        )

        for (pattern in patterns) {
            val match = Regex(pattern).find(text)
            if (match != null) {
                return if (match.groupValues.size > 1) {
                    match.groupValues[1].trim()
                } else {
                    "current_email"
                }
            }
        }
        return null
    }

    /**
     * Extrai palavras-chave do texto
     */
    private fun extractKeywords(text: String): List<String> {
        // Remove palavras comuns e extrai palavras-chave
        val stopWords = setOf(
            "o", "a", "os", "as", "de", "da", "do", "das", "dos", "em", "na", "no", "nas", "nos",
            "para", "por", "com", "sem", "sobre", "entre", "até", "desde", "durante", "através",
            "e", "ou", "mas", "que", "se", "quando", "onde", "como", "por que", "porque",
            "email", "e-mail", "emails", "e-mails", "mensagem", "mensagens"
        )

        return text.split("\\s+".toRegex())
            .map { it.lowercase().replace(Regex("[^a-záàâãéèêíìîóòôõúùûç]"), "") }
            .filter { it.length > 2 && !stopWords.contains(it) }
            .distinct()
    }

    /**
     * Verifica se o texto corresponde a algum padrão
     */
    private fun matchesPatterns(text: String, patterns: List<String>): Boolean {
        return patterns.any { pattern ->
            text.contains(Regex(pattern))
        }
    }

    /**
     * Calcula confiança do comando baseado na clareza
     */
    private fun calculateConfidence(text: String, intent: CommandIntent): Float {
        var confidence = 0.5f // Base

        // Aumenta confiança se a intenção foi detectada claramente
        if (intent != CommandIntent.UNKNOWN) {
            confidence += 0.3f
        }

        // Aumenta confiança se contém palavras-chave específicas
        if (text.contains("e-mail") || text.contains("email")) {
            confidence += 0.1f
        }

        // Aumenta confiança se contém parâmetros específicos
        if (text.contains(Regex("\\d+"))) { // Contém números
            confidence += 0.05f
        }

        // Diminui confiança se o texto é muito curto ou muito longo
        when {
            text.length < 5 -> confidence -= 0.2f
            text.length > 100 -> confidence -= 0.1f
        }

        return confidence.coerceIn(0.0f, 1.0f)
    }
}

