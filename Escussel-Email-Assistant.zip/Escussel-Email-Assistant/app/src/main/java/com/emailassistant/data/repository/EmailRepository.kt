package com.emailassistant.data.repository

import com.emailassistant.data.model.Email
import com.emailassistant.data.model.DateRange
import kotlinx.coroutines.flow.Flow

/**
 * Interface do repositório para operações com e-mails
 */
interface EmailRepository {
    
    /**
     * Obtém e-mails dentro de um range de datas
     */
    suspend fun getEmailsByDateRange(dateRange: DateRange): Result<List<Email>>
    
    /**
     * Obtém e-mails por remetente
     */
    suspend fun getEmailsBySender(senderAddress: String, dateRange: DateRange? = null): Result<List<Email>>
    
    /**
     * Busca e-mails por palavras-chave
     */
    suspend fun searchEmails(keywords: List<String>, dateRange: DateRange? = null): Result<List<Email>>
    
    /**
     * Obtém um e-mail específico por ID
     */
    suspend fun getEmailById(emailId: String): Result<Email>
    
    /**
     * Envia um novo e-mail
     */
    suspend fun sendEmail(
        recipient: String,
        subject: String,
        body: String,
        replyToEmailId: String? = null
    ): Result<Boolean>
    
    /**
     * Responde a um e-mail específico
     */
    suspend fun replyToEmail(
        emailId: String,
        replyBody: String,
        replyToAll: Boolean = false
    ): Result<Boolean>
    
    /**
     * Marca e-mail como lido/não lido
     */
    suspend fun markEmailAsRead(emailId: String, isRead: Boolean): Result<Boolean>
    
    /**
     * Arquiva um e-mail (move para pasta de arquivo)
     */
    suspend fun archiveEmail(emailId: String): Result<Boolean>
    
    /**
     * Exclui um e-mail permanentemente
     */
    suspend fun deleteEmail(emailId: String): Result<Boolean>
    
    /**
     * Move e-mail para uma pasta específica
     */
    suspend fun moveEmailToFolder(emailId: String, folderName: String): Result<Boolean>
    
    /**
     * Adiciona ou remove flag de um e-mail
     */
    suspend fun flagEmail(emailId: String, flagged: Boolean): Result<Boolean>
    
    /**
     * Obtém lista de pastas disponíveis
     */
    suspend fun getAvailableFolders(): Result<List<String>>
    
    /**
     * Obtém e-mails em cache (offline)
     */
    fun getCachedEmails(): Flow<List<Email>>
    
    /**
     * Sincroniza e-mails com o servidor
     */
    suspend fun syncEmails(): Result<Boolean>
    
    /**
     * Verifica se há conexão com o servidor
     */
    suspend fun isConnected(): Boolean
}

