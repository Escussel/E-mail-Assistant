package com.emailassistant.data.storage

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

/**
 * Database Room para cache local de e-mails
 */
@Database(
    entities = [CachedEmailEntity::class],
    version = 1,
    exportSchema = false
)
abstract class EmailDatabase : RoomDatabase() {
    
    abstract fun emailCacheDao(): EmailCacheDao

    companion object {
        const val DATABASE_NAME = "email_cache.db"
        
        fun create(context: Context): EmailDatabase {
            return Room.databaseBuilder(
                context,
                EmailDatabase::class.java,
                DATABASE_NAME
            )
            .fallbackToDestructiveMigration()
            .build()
        }
    }
}

