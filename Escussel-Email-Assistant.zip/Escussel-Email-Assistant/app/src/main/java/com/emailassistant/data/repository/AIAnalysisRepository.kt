package com.emailassistant.data.repository

import com.emailassistant.data.model.Email
import com.emailassistant.data.model.EmailAnalysis
import com.emailassistant.data.model.SimilarityGroup

/**
 * Interface do repositório para análise inteligente de e-mails
 */
interface AIAnalysisRepository {
    
    /**
     * Analisa uma lista de e-mails e gera insights
     */
    suspend fun analyzeEmails(emails: List<Email>): Result<EmailAnalysis>
    
    /**
     * Gera resumo conversacional dos e-mails
     */
    suspend fun generateEmailSummary(emails: List<Email>): Result<String>
    
    /**
     * Encontra e-mails similares baseado em conteúdo
     */
    suspend fun findSimilarEmails(targetEmail: Email, allEmails: List<Email>): Result<List<SimilarityGroup>>
    
    /**
     * Responde perguntas sobre o conteúdo dos e-mails
     */
    suspend fun answerQuestion(
        question: String,
        emails: List<Email>,
        conversationHistory: List<String> = emptyList()
    ): Result<String>
    
    /**
     * Gera resposta para um e-mail baseado no contexto
     */
    suspend fun generateEmailResponse(
        originalEmail: Email,
        userInstruction: String,
        conversationContext: List<Email> = emptyList()
    ): Result<String>
    
    /**
     * Extrai tópicos principais dos e-mails
     */
    suspend fun extractKeyTopics(emails: List<Email>): Result<List<String>>
    
    /**
     * Analisa sentimento dos e-mails
     */
    suspend fun analyzeSentiment(emails: List<Email>): Result<Map<String, String>>
    
    /**
     * Identifica itens acionáveis nos e-mails
     */
    suspend fun identifyActionableItems(emails: List<Email>): Result<List<String>>
    
    /**
     * Calcula similaridade entre dois textos
     */
    suspend fun calculateTextSimilarity(text1: String, text2: String): Result<Float>
}

