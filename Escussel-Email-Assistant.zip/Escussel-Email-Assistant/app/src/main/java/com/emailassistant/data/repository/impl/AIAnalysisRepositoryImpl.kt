package com.emailassistant.data.repository.impl

import com.emailassistant.data.ai.OpenAIService
import com.emailassistant.data.ai.TextSimilarityService
import com.emailassistant.data.model.*
import com.emailassistant.data.repository.AIAnalysisRepository
import com.emailassistant.data.storage.AuthTokenManager
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Implementação do repositório de análise de IA
 */
@Singleton
class AIAnalysisRepositoryImpl @Inject constructor(
    private val openAIService: OpenAIService,
    private val textSimilarityService: TextSimilarityService,
    private val authTokenManager: AuthTokenManager
) : AIAnalysisRepository {

    companion object {
        private const val DEFAULT_API_KEY = "sk-your-openai-api-key" // Será configurado pelo usuário
    }

    override suspend fun analyzeEmails(emails: List<Email>): Result<EmailAnalysis> {
        return try {
            if (emails.isEmpty()) {
                return Result.failure(Exception("Lista de e-mails vazia"))
            }

            val apiKey = getOpenAIApiKey()
            
            Timber.d("Iniciando análise de ${emails.size} e-mails")

            // Gerar resumo
            val summary = generateEmailSummary(emails).getOrElse { 
                "Resumo não disponível: ${it.message}" 
            }

            // Extrair tópicos principais
            val keyTopics = extractKeyTopics(emails).getOrElse { 
                listOf("Tópicos não disponíveis") 
            }

            // Análise de sentimento
            val sentimentAnalysis = analyzeSentimentInternal(emails, apiKey)

            // Encontrar grupos similares
            val similarityGroups = textSimilarityService.findSimilarEmailGroups(emails, apiKey)
                .getOrElse { emptyList() }

            // Identificar itens acionáveis
            val actionableItems = identifyActionableItemsInternal(emails, apiKey)

            // Criar contexto conversacional
            val conversationContext = ConversationContext(
                previousQuestions = emptyList(),
                currentFocus = "Análise geral de ${emails.size} e-mails",
                availableActions = listOf(
                    "Fazer pergunta sobre os e-mails",
                    "Ver e-mails similares",
                    "Analisar sentimento",
                    "Identificar ações necessárias"
                )
            )

            val analysis = EmailAnalysis(
                emails = emails,
                summary = summary,
                keyTopics = keyTopics,
                sentimentAnalysis = sentimentAnalysis,
                similarityGroups = similarityGroups,
                actionableItems = actionableItems,
                conversationContext = conversationContext
            )

            Timber.d("Análise concluída com sucesso")
            Result.success(analysis)

        } catch (e: Exception) {
            Timber.e(e, "Erro na análise de e-mails")
            Result.failure(e)
        }
    }

    override suspend fun generateEmailSummary(emails: List<Email>): Result<String> {
        return try {
            val apiKey = getOpenAIApiKey()
            val emailTexts = emails.map { formatEmailForAnalysis(it) }

            val result = openAIService.analyzeEmails(
                emails = emailTexts,
                analysisType = "summary",
                apiKey = apiKey
            )

            result.fold(
                onSuccess = { summary ->
                    Timber.d("Resumo gerado com sucesso")
                    Result.success(summary)
                },
                onFailure = { exception ->
                    Timber.w("Gerando resumo fallback: ${exception.message}")
                    val fallbackSummary = generateFallbackSummary(emails)
                    Result.success(fallbackSummary)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao gerar resumo")
            Result.failure(e)
        }
    }

    override suspend fun findSimilarEmails(
        targetEmail: Email,
        allEmails: List<Email>
    ): Result<List<SimilarityGroup>> {
        return try {
            val apiKey = getOpenAIApiKey()
            
            val similarEmails = textSimilarityService.findSimilarEmails(
                targetEmail = targetEmail,
                allEmails = allEmails,
                apiKey = apiKey,
                maxResults = 10
            ).getOrElse { emptyList() }

            if (similarEmails.isNotEmpty()) {
                val group = SimilarityGroup(
                    id = "similar_to_${targetEmail.id}",
                    emails = similarEmails,
                    commonTheme = "E-mails similares a: ${targetEmail.subject}",
                    similarityScore = 0.8f
                )
                Result.success(listOf(group))
            } else {
                Result.success(emptyList())
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao encontrar e-mails similares")
            Result.failure(e)
        }
    }

    override suspend fun answerQuestion(
        question: String,
        emails: List<Email>,
        conversationHistory: List<String>
    ): Result<String> {
        return try {
            val apiKey = getOpenAIApiKey()
            val emailContext = emails.joinToString("\n\n") { formatEmailForAnalysis(it) }

            val result = openAIService.answerQuestion(
                question = question,
                emailContext = emailContext,
                conversationHistory = conversationHistory,
                apiKey = apiKey
            )

            result.fold(
                onSuccess = { answer ->
                    Timber.d("Pergunta respondida com sucesso")
                    Result.success(answer)
                },
                onFailure = { exception ->
                    Timber.w("Gerando resposta fallback: ${exception.message}")
                    val fallbackAnswer = generateFallbackAnswer(question, emails)
                    Result.success(fallbackAnswer)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao responder pergunta")
            Result.failure(e)
        }
    }

    override suspend fun generateEmailResponse(
        originalEmail: Email,
        userInstruction: String,
        conversationContext: List<Email>
    ): Result<String> {
        return try {
            val apiKey = getOpenAIApiKey()
            val originalEmailText = formatEmailForAnalysis(originalEmail)
            val contextText = conversationContext.joinToString("\n") { formatEmailForAnalysis(it) }

            val result = openAIService.generateEmailResponse(
                originalEmail = originalEmailText,
                userInstruction = userInstruction,
                context = contextText,
                apiKey = apiKey
            )

            result.fold(
                onSuccess = { response ->
                    Timber.d("Resposta de e-mail gerada com sucesso")
                    Result.success(response)
                },
                onFailure = { exception ->
                    Timber.w("Gerando resposta fallback: ${exception.message}")
                    val fallbackResponse = generateFallbackEmailResponse(originalEmail, userInstruction)
                    Result.success(fallbackResponse)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao gerar resposta de e-mail")
            Result.failure(e)
        }
    }

    override suspend fun extractKeyTopics(emails: List<Email>): Result<List<String>> {
        return try {
            val apiKey = getOpenAIApiKey()
            
            val result = textSimilarityService.extractTopics(emails, apiKey)
            
            result.fold(
                onSuccess = { topics ->
                    Timber.d("Tópicos extraídos: ${topics.size}")
                    Result.success(topics)
                },
                onFailure = { exception ->
                    Timber.w("Extraindo tópicos fallback: ${exception.message}")
                    val fallbackTopics = extractTopicsFallback(emails)
                    Result.success(fallbackTopics)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro ao extrair tópicos")
            Result.failure(e)
        }
    }

    override suspend fun analyzeSentiment(emails: List<Email>): Result<Map<String, String>> {
        return try {
            val apiKey = getOpenAIApiKey()
            val emailTexts = emails.map { formatEmailForAnalysis(it) }

            val result = openAIService.analyzeEmails(
                emails = emailTexts,
                analysisType = "sentiment",
                apiKey = apiKey
            )

            result.fold(
                onSuccess = { sentimentText ->
                    val sentimentMap = parseSentimentAnalysis(sentimentText, emails)
                    Timber.d("Análise de sentimento concluída")
                    Result.success(sentimentMap)
                },
                onFailure = { exception ->
                    Timber.w("Análise de sentimento fallback: ${exception.message}")
                    val fallbackSentiment = analyzeSentimentFallback(emails)
                    Result.success(fallbackSentiment)
                }
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro na análise de sentimento")
            Result.failure(e)
        }
    }

    override suspend fun identifyActionableItems(emails: List<Email>): Result<List<String>> {
        return try {
            val apiKey = getOpenAIApiKey()
            val actionableItems = identifyActionableItemsInternal(emails, apiKey)
            Result.success(actionableItems.map { it.description })
        } catch (e: Exception) {
            Timber.e(e, "Erro ao identificar itens acionáveis")
            Result.failure(e)
        }
    }

    override suspend fun calculateTextSimilarity(text1: String, text2: String): Result<Float> {
        return try {
            val apiKey = getOpenAIApiKey()
            textSimilarityService.calculateCosineSimilarity(text1, text2, apiKey)
        } catch (e: Exception) {
            Timber.e(e, "Erro ao calcular similaridade")
            Result.failure(e)
        }
    }

    // Métodos auxiliares privados

    private fun getOpenAIApiKey(): String {
        // TODO: Implementar obtenção da chave da API das configurações do usuário
        return DEFAULT_API_KEY
    }

    private fun formatEmailForAnalysis(email: Email): String {
        return """
        Assunto: ${email.subject}
        De: ${email.sender.name} <${email.sender.address}>
        Data: ${email.receivedDateTime}
        Conteúdo: ${email.bodyPreview}
        """.trimIndent()
    }

    private fun analyzeSentimentInternal(emails: List<Email>, apiKey: String): SentimentAnalysis {
        return try {
            // Análise básica de sentimento baseada em palavras-chave
            val positiveWords = listOf("obrigado", "parabéns", "excelente", "ótimo", "sucesso", "feliz")
            val negativeWords = listOf("problema", "erro", "urgente", "preocupado", "falha", "cancelar")
            
            var positiveCount = 0
            var negativeCount = 0
            
            emails.forEach { email ->
                val text = "${email.subject} ${email.bodyPreview}".lowercase()
                positiveCount += positiveWords.count { text.contains(it) }
                negativeCount += negativeWords.count { text.contains(it) }
            }
            
            val overallSentiment = when {
                positiveCount > negativeCount -> Sentiment.POSITIVE
                negativeCount > positiveCount -> Sentiment.NEGATIVE
                else -> Sentiment.NEUTRAL
            }
            
            val confidence = if (positiveCount + negativeCount > 0) {
                maxOf(positiveCount, negativeCount).toFloat() / (positiveCount + negativeCount)
            } else {
                0.5f
            }
            
            SentimentAnalysis(
                overallSentiment = overallSentiment,
                confidenceScore = confidence,
                emotionalTone = listOf(
                    EmotionalTone("profissional", 0.8f),
                    EmotionalTone("neutro", 0.6f)
                )
            )
        } catch (e: Exception) {
            Timber.e(e, "Erro na análise de sentimento interna")
            SentimentAnalysis(
                overallSentiment = Sentiment.NEUTRAL,
                confidenceScore = 0.5f,
                emotionalTone = emptyList()
            )
        }
    }

    private fun identifyActionableItemsInternal(emails: List<Email>, apiKey: String): List<ActionableItem> {
        return try {
            val actionableItems = mutableListOf<ActionableItem>()
            
            emails.forEach { email ->
                val text = "${email.subject} ${email.bodyPreview}".lowercase()
                
                when {
                    text.contains("reunião") || text.contains("meeting") -> {
                        actionableItems.add(ActionableItem(
                            type = ActionType.MEETING_REQUEST,
                            description = "Reunião mencionada em: ${email.subject}",
                            priority = Priority.MEDIUM,
                            relatedEmails = listOf(email.id)
                        ))
                    }
                    text.contains("prazo") || text.contains("deadline") -> {
                        actionableItems.add(ActionableItem(
                            type = ActionType.DEADLINE,
                            description = "Prazo mencionado em: ${email.subject}",
                            priority = Priority.HIGH,
                            relatedEmails = listOf(email.id)
                        ))
                    }
                    text.contains("responder") || text.contains("reply") -> {
                        actionableItems.add(ActionableItem(
                            type = ActionType.REPLY_REQUIRED,
                            description = "Resposta necessária para: ${email.subject}",
                            priority = Priority.MEDIUM,
                            relatedEmails = listOf(email.id)
                        ))
                    }
                    text.contains("informação") || text.contains("information") -> {
                        actionableItems.add(ActionableItem(
                            type = ActionType.INFORMATION_REQUEST,
                            description = "Informação solicitada em: ${email.subject}",
                            priority = Priority.LOW,
                            relatedEmails = listOf(email.id)
                        ))
                    }
                }
            }
            
            actionableItems
        } catch (e: Exception) {
            Timber.e(e, "Erro ao identificar itens acionáveis")
            emptyList()
        }
    }

    private fun generateFallbackSummary(emails: List<Email>): String {
        return try {
            val totalEmails = emails.size
            val senders = emails.map { it.sender.name }.distinct()
            val subjects = emails.map { it.subject }.take(3)
            
            """
            Resumo de $totalEmails e-mails:
            
            Principais remetentes: ${senders.take(3).joinToString(", ")}
            
            Assuntos recentes:
            ${subjects.joinToString("\n") { "• $it" }}
            
            ${if (totalEmails > 3) "... e mais ${totalEmails - 3} e-mails" else ""}
            """.trimIndent()
        } catch (e: Exception) {
            "Resumo não disponível devido a erro técnico."
        }
    }

    private fun generateFallbackAnswer(question: String, emails: List<Email>): String {
        return "Desculpe, não consegui processar sua pergunta no momento. " +
                "Você perguntou sobre: \"$question\". " +
                "Tenho ${emails.size} e-mails disponíveis para análise."
    }

    private fun generateFallbackEmailResponse(email: Email, instruction: String): String {
        return """
        Olá,
        
        Obrigado pelo seu e-mail sobre "${email.subject}".
        
        ${instruction}
        
        Atenciosamente
        """.trimIndent()
    }

    private fun extractTopicsFallback(emails: List<Email>): List<String> {
        val words = emails.flatMap { email ->
            "${email.subject} ${email.bodyPreview}".split("\\s+".toRegex())
        }
        
        return words
            .filter { it.length > 3 }
            .groupingBy { it.lowercase() }
            .eachCount()
            .toList()
            .sortedByDescending { it.second }
            .take(5)
            .map { it.first }
    }

    private fun analyzeSentimentFallback(emails: List<Email>): Map<String, String> {
        return emails.associate { email ->
            email.id to "neutro"
        }
    }

    private fun parseSentimentAnalysis(sentimentText: String, emails: List<Email>): Map<String, String> {
        // Parse básico do texto de análise de sentimento
        return emails.associate { email ->
            email.id to when {
                sentimentText.contains("positivo", ignoreCase = true) -> "positivo"
                sentimentText.contains("negativo", ignoreCase = true) -> "negativo"
                else -> "neutro"
            }
        }
    }
}

