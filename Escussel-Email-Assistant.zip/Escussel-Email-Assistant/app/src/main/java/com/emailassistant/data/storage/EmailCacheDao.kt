package com.emailassistant.data.storage

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * DAO para cache local de e-mails
 */
@Dao
interface EmailCacheDao {

    @Query("SELECT * FROM cached_emails ORDER BY receivedDateTime DESC")
    fun getAllEmails(): Flow<List<CachedEmailEntity>>

    @Query("SELECT * FROM cached_emails WHERE id = :emailId")
    suspend fun getEmailById(emailId: String): CachedEmailEntity?

    @Query("SELECT * FROM cached_emails WHERE receivedDateTime BETWEEN :startDate AND :endDate ORDER BY receivedDateTime DESC")
    suspend fun getEmailsByDateRange(startDate: Long, endDate: Long): List<CachedEmailEntity>

    @Query("SELECT * FROM cached_emails WHERE senderAddress = :senderAddress ORDER BY receivedDateTime DESC")
    suspend fun getEmailsBySender(senderAddress: String): List<CachedEmailEntity>

    @Query("SELECT * FROM cached_emails WHERE subject LIKE '%' || :keyword || '%' OR bodyPreview LIKE '%' || :keyword || '%' ORDER BY receivedDateTime DESC")
    suspend fun searchEmails(keyword: String): List<CachedEmailEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmail(email: CachedEmailEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmails(emails: List<CachedEmailEntity>)

    @Update
    suspend fun updateEmail(email: CachedEmailEntity)

    @Delete
    suspend fun deleteEmail(email: CachedEmailEntity)

    @Query("DELETE FROM cached_emails WHERE id = :emailId")
    suspend fun deleteEmail(emailId: String)

    @Query("DELETE FROM cached_emails")
    suspend fun clearAllEmails()

    @Query("DELETE FROM cached_emails WHERE receivedDateTime < :cutoffDate")
    suspend fun deleteOldEmails(cutoffDate: Long)

    @Query("SELECT COUNT(*) FROM cached_emails")
    suspend fun getEmailCount(): Int

    @Query("SELECT COUNT(*) FROM cached_emails WHERE isRead = 0")
    suspend fun getUnreadEmailCount(): Int
}

/**
 * Entidade para cache de e-mails no Room
 */
@Entity(tableName = "cached_emails")
data class CachedEmailEntity(
    @PrimaryKey
    val id: String,
    val subject: String,
    val senderName: String,
    val senderAddress: String,
    val recipients: String, // JSON string
    val body: String,
    val bodyPreview: String,
    val receivedDateTime: Long,
    val isRead: Boolean,
    val importance: String,
    val hasAttachments: Boolean,
    val conversationId: String,
    val categories: String, // JSON string
    val flagStatus: String?,
    val flagDueDateTime: Long?,
    val lastSyncTime: Long = System.currentTimeMillis()
)

