package com.emailassistant.data.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import timber.log.Timber
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Serviço de reconhecimento de voz usando Android Speech API
 */
@Singleton
class SpeechRecognitionService @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    companion object {
        private const val LANGUAGE_CODE = "pt-BR"
        private const val MAX_RESULTS = 5
    }

    /**
     * Inicia reconhecimento de voz e retorna Flow com resultados
     */
    fun startListening(): Flow<SpeechRecognitionResult> = callbackFlow {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                trySend(SpeechRecognitionResult.Error("Reconhecimento de voz não disponível"))
                close()
                return@callbackFlow
            }

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            
            val recognitionListener = object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    Timber.d("Pronto para ouvir")
                    trySend(SpeechRecognitionResult.ReadyForSpeech)
                }

                override fun onBeginningOfSpeech() {
                    Timber.d("Início da fala detectado")
                    trySend(SpeechRecognitionResult.BeginningOfSpeech)
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Nível de volume da voz
                    trySend(SpeechRecognitionResult.VolumeChanged(rmsdB))
                }

                override fun onBufferReceived(buffer: ByteArray?) {
                    // Buffer de áudio recebido
                }

                override fun onEndOfSpeech() {
                    Timber.d("Fim da fala detectado")
                    trySend(SpeechRecognitionResult.EndOfSpeech)
                }

                override fun onError(error: Int) {
                    val errorMessage = getErrorMessage(error)
                    Timber.e("Erro no reconhecimento: $errorMessage")
                    trySend(SpeechRecognitionResult.Error(errorMessage))
                    isListening = false
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val confidence = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                    
                    if (!matches.isNullOrEmpty()) {
                        val bestMatch = matches[0]
                        val bestConfidence = confidence?.get(0) ?: 0.5f
                        
                        Timber.d("Texto reconhecido: $bestMatch (confiança: $bestConfidence)")
                        trySend(SpeechRecognitionResult.Success(bestMatch, bestConfidence, matches))
                    } else {
                        trySend(SpeechRecognitionResult.Error("Nenhum texto reconhecido"))
                    }
                    
                    isListening = false
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val partialText = matches[0]
                        Timber.d("Resultado parcial: $partialText")
                        trySend(SpeechRecognitionResult.PartialResult(partialText))
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {
                    // Eventos adicionais
                }
            }

            speechRecognizer?.setRecognitionListener(recognitionListener)

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGUAGE_CODE)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, LANGUAGE_CODE)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, MAX_RESULTS)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
            }

            speechRecognizer?.startListening(intent)
            isListening = true

        } catch (e: Exception) {
            Timber.e(e, "Erro ao iniciar reconhecimento")
            trySend(SpeechRecognitionResult.Error("Erro ao iniciar reconhecimento: ${e.message}"))
        }

        awaitClose {
            stopListening()
        }
    }

    /**
     * Para o reconhecimento de voz
     */
    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
            isListening = false
            Timber.d("Reconhecimento de voz parado")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao parar reconhecimento")
        }
    }

    /**
     * Verifica se está ouvindo
     */
    fun isListening(): Boolean = isListening

    /**
     * Verifica se reconhecimento está disponível
     */
    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Obtém idiomas disponíveis
     */
    fun getAvailableLanguages(): List<String> {
        return listOf(
            "pt-BR", // Português brasileiro
            "pt-PT", // Português europeu
            "en-US", // Inglês americano
            "es-ES"  // Espanhol
        )
    }

    /**
     * Converte código de erro em mensagem legível
     */
    private fun getErrorMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Erro de áudio"
            SpeechRecognizer.ERROR_CLIENT -> "Erro do cliente"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissões insuficientes"
            SpeechRecognizer.ERROR_NETWORK -> "Erro de rede"
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Timeout de rede"
            SpeechRecognizer.ERROR_NO_MATCH -> "Nenhuma correspondência encontrada"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reconhecedor ocupado"
            SpeechRecognizer.ERROR_SERVER -> "Erro do servidor"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Timeout de fala"
            else -> "Erro desconhecido ($errorCode)"
        }
    }
}

/**
 * Resultado do reconhecimento de voz
 */
sealed class SpeechRecognitionResult {
    object ReadyForSpeech : SpeechRecognitionResult()
    object BeginningOfSpeech : SpeechRecognitionResult()
    object EndOfSpeech : SpeechRecognitionResult()
    data class VolumeChanged(val volume: Float) : SpeechRecognitionResult()
    data class PartialResult(val text: String) : SpeechRecognitionResult()
    data class Success(
        val text: String,
        val confidence: Float,
        val alternatives: List<String>
    ) : SpeechRecognitionResult()
    data class Error(val message: String) : SpeechRecognitionResult()
}

