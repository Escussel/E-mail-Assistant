package com.emailassistant.data.ai

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Interface da API OpenAI
 */
interface OpenAIApi {
    
    @POST("chat/completions")
    suspend fun createChatCompletion(
        @Header("Authorization") authorization: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>

    @POST("embeddings")
    suspend fun createEmbeddings(
        @Header("Authorization") authorization: String,
        @Header("Content-Type") contentType: String = "application/json",
        @Body request: EmbeddingRequest
    ): Response<EmbeddingResponse>
}

/**
 * Serviço para integração com OpenAI
 */
@Singleton
class OpenAIService @Inject constructor(
    private val api: OpenAIApi
) {
    
    companion object {
        private const val MODEL_GPT_4 = "gpt-4"
        private const val MODEL_GPT_35_TURBO = "gpt-3.5-turbo"
        private const val MODEL_EMBEDDING = "text-embedding-ada-002"
        private const val MAX_TOKENS = 2000
        private const val TEMPERATURE = 0.7
    }

    /**
     * Analisa e-mails usando GPT
     */
    suspend fun analyzeEmails(
        emails: List<String>,
        analysisType: String,
        apiKey: String
    ): Result<String> {
        return try {
            val prompt = buildAnalysisPrompt(emails, analysisType)
            
            val request = ChatCompletionRequest(
                model = MODEL_GPT_35_TURBO,
                messages = listOf(
                    ChatMessage(
                        role = "system",
                        content = getSystemPrompt(analysisType)
                    ),
                    ChatMessage(
                        role = "user",
                        content = prompt
                    )
                ),
                maxTokens = MAX_TOKENS,
                temperature = TEMPERATURE
            )

            val response = api.createChatCompletion(
                authorization = "Bearer $apiKey",
                request = request
            )

            if (response.isSuccessful) {
                val completion = response.body()?.choices?.firstOrNull()?.message?.content
                    ?: return Result.failure(Exception("Resposta vazia da API"))
                
                Timber.d("Análise concluída com sucesso")
                Result.success(completion)
            } else {
                val error = "Erro na API OpenAI: ${response.code()} - ${response.message()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao analisar e-mails")
            Result.failure(e)
        }
    }

    /**
     * Gera embeddings para similaridade de texto
     */
    suspend fun generateEmbeddings(
        texts: List<String>,
        apiKey: String
    ): Result<List<List<Double>>> {
        return try {
            val request = EmbeddingRequest(
                model = MODEL_EMBEDDING,
                input = texts
            )

            val response = api.createEmbeddings(
                authorization = "Bearer $apiKey",
                request = request
            )

            if (response.isSuccessful) {
                val embeddings = response.body()?.data?.map { it.embedding }
                    ?: return Result.failure(Exception("Embeddings vazios"))
                
                Timber.d("Embeddings gerados para ${texts.size} textos")
                Result.success(embeddings)
            } else {
                val error = "Erro na API OpenAI: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao gerar embeddings")
            Result.failure(e)
        }
    }

    /**
     * Responde pergunta sobre e-mails
     */
    suspend fun answerQuestion(
        question: String,
        emailContext: String,
        conversationHistory: List<String>,
        apiKey: String
    ): Result<String> {
        return try {
            val messages = mutableListOf<ChatMessage>()
            
            // Sistema
            messages.add(ChatMessage(
                role = "system",
                content = """
                Você é um assistente especializado em análise de e-mails. Responda perguntas sobre o conteúdo dos e-mails de forma clara e conversacional em português brasileiro.
                
                Contexto dos e-mails:
                $emailContext
                
                Instruções:
                - Seja preciso e objetivo
                - Use informações apenas dos e-mails fornecidos
                - Se não souber algo, diga que não tem essa informação
                - Mantenha um tom conversacional e amigável
                """.trimIndent()
            ))
            
            // Histórico da conversa
            conversationHistory.takeLast(6).forEachIndexed { index, message ->
                val role = if (index % 2 == 0) "user" else "assistant"
                messages.add(ChatMessage(role = role, content = message))
            }
            
            // Pergunta atual
            messages.add(ChatMessage(role = "user", content = question))

            val request = ChatCompletionRequest(
                model = MODEL_GPT_35_TURBO,
                messages = messages,
                maxTokens = MAX_TOKENS,
                temperature = TEMPERATURE
            )

            val response = api.createChatCompletion(
                authorization = "Bearer $apiKey",
                request = request
            )

            if (response.isSuccessful) {
                val answer = response.body()?.choices?.firstOrNull()?.message?.content
                    ?: return Result.failure(Exception("Resposta vazia"))
                
                Timber.d("Pergunta respondida com sucesso")
                Result.success(answer)
            } else {
                val error = "Erro na API: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao responder pergunta")
            Result.failure(e)
        }
    }

    /**
     * Gera resposta para e-mail
     */
    suspend fun generateEmailResponse(
        originalEmail: String,
        userInstruction: String,
        context: String,
        apiKey: String
    ): Result<String> {
        return try {
            val prompt = """
            E-mail original:
            $originalEmail
            
            Contexto adicional:
            $context
            
            Instrução do usuário:
            $userInstruction
            
            Gere uma resposta profissional e adequada para este e-mail seguindo a instrução do usuário.
            """.trimIndent()

            val request = ChatCompletionRequest(
                model = MODEL_GPT_35_TURBO,
                messages = listOf(
                    ChatMessage(
                        role = "system",
                        content = """
                        Você é um assistente para composição de e-mails profissionais em português brasileiro.
                        Gere respostas claras, educadas e apropriadas ao contexto.
                        Mantenha um tom profissional mas amigável.
                        """.trimIndent()
                    ),
                    ChatMessage(role = "user", content = prompt)
                ),
                maxTokens = MAX_TOKENS,
                temperature = TEMPERATURE
            )

            val response = api.createChatCompletion(
                authorization = "Bearer $apiKey",
                request = request
            )

            if (response.isSuccessful) {
                val emailResponse = response.body()?.choices?.firstOrNull()?.message?.content
                    ?: return Result.failure(Exception("Resposta vazia"))
                
                Timber.d("Resposta de e-mail gerada com sucesso")
                Result.success(emailResponse)
            } else {
                val error = "Erro na API: ${response.code()}"
                Timber.e(error)
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Erro ao gerar resposta de e-mail")
            Result.failure(e)
        }
    }

    private fun buildAnalysisPrompt(emails: List<String>, analysisType: String): String {
        val emailsText = emails.joinToString("\n\n---\n\n") { "E-mail: $it" }
        
        return when (analysisType) {
            "summary" -> """
                Analise os seguintes e-mails e forneça um resumo conversacional em português brasileiro:
                
                $emailsText
                
                Forneça um resumo que inclua:
                - Principais tópicos discutidos
                - Ações necessárias
                - Pessoas envolvidas
                - Prazos importantes
                """.trimIndent()
                
            "sentiment" -> """
                Analise o sentimento dos seguintes e-mails:
                
                $emailsText
                
                Para cada e-mail, identifique:
                - Sentimento geral (positivo, neutro, negativo)
                - Tom emocional
                - Urgência
                """.trimIndent()
                
            "topics" -> """
                Extraia os principais tópicos dos seguintes e-mails:
                
                $emailsText
                
                Liste os tópicos principais e suas frequências.
                """.trimIndent()
                
            "actionable" -> """
                Identifique itens acionáveis nos seguintes e-mails:
                
                $emailsText
                
                Liste:
                - Tarefas a serem realizadas
                - Prazos
                - Pessoas responsáveis
                - Prioridades
                """.trimIndent()
                
            else -> """
                Analise os seguintes e-mails e forneça insights úteis:
                
                $emailsText
                """.trimIndent()
        }
    }

    private fun getSystemPrompt(analysisType: String): String {
        return when (analysisType) {
            "summary" -> """
                Você é um assistente especializado em resumir e-mails de forma conversacional.
                Forneça resumos claros e úteis em português brasileiro, destacando informações importantes.
                """.trimIndent()
                
            "sentiment" -> """
                Você é um especialista em análise de sentimento de e-mails.
                Analise o tom, emoções e urgência das mensagens de forma precisa.
                """.trimIndent()
                
            "topics" -> """
                Você é um especialista em extração de tópicos de e-mails.
                Identifique e categorize os principais assuntos discutidos.
                """.trimIndent()
                
            "actionable" -> """
                Você é um especialista em identificar itens acionáveis em e-mails.
                Encontre tarefas, prazos e responsabilidades de forma clara e organizada.
                """.trimIndent()
                
            else -> """
                Você é um assistente de análise de e-mails. Forneça insights úteis e precisos.
                """.trimIndent()
        }
    }
}

// DTOs para OpenAI API

data class ChatCompletionRequest(
    @SerializedName("model") val model: String,
    @SerializedName("messages") val messages: List<ChatMessage>,
    @SerializedName("max_tokens") val maxTokens: Int,
    @SerializedName("temperature") val temperature: Double
)

data class ChatMessage(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String
)

data class ChatCompletionResponse(
    @SerializedName("choices") val choices: List<ChatChoice>
)

data class ChatChoice(
    @SerializedName("message") val message: ChatMessage
)

data class EmbeddingRequest(
    @SerializedName("model") val model: String,
    @SerializedName("input") val input: List<String>
)

data class EmbeddingResponse(
    @SerializedName("data") val data: List<EmbeddingData>
)

data class EmbeddingData(
    @SerializedName("embedding") val embedding: List<Double>
)

