package com.emailassistant.ui.setup

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.emailassistant.data.storage.ConfigurationManager
import com.emailassistant.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * ViewModel da tela de configuração
 */
@HiltViewModel
class SetupViewModel @Inject constructor(
    private val configurationManager: ConfigurationManager
) : BaseViewModel() {

    private val _configurationSaved = MutableLiveData<Boolean>()
    val configurationSaved: LiveData<Boolean> = _configurationSaved

    private val _connectionTestResult = MutableLiveData<Boolean>()
    val connectionTestResult: LiveData<Boolean> = _connectionTestResult

    private val _configurationLoaded = MutableLiveData<Map<String, Any>>()
    val configurationLoaded: LiveData<Map<String, Any>> = _configurationLoaded

    // Configurações temporárias (antes de salvar)
    private var tempSpeechRate: Float = 1.0f
    private var tempSpeechPitch: Float = 1.0f
    private var tempLanguage: String = "pt-BR"
    private var tempVoiceFeedbackEnabled: Boolean = true
    private var tempHandsFreeModeEnabled: Boolean = false
    private var tempNotificationsEnabled: Boolean = true

    suspend fun loadCurrentConfiguration() {
        try {
            setLoading(true)
            
            // Carregar configurações atuais
            val config = configurationManager.exportConfiguration()
            _configurationLoaded.value = config
            
            // Atualizar variáveis temporárias
            tempSpeechRate = config["speech_rate"] as? Float ?: 1.0f
            tempSpeechPitch = config["speech_pitch"] as? Float ?: 1.0f
            tempLanguage = config["language"] as? String ?: "pt-BR"
            tempVoiceFeedbackEnabled = config["voice_feedback_enabled"] as? Boolean ?: true
            tempHandsFreeModeEnabled = config["hands_free_mode"] as? Boolean ?: false
            tempNotificationsEnabled = config["notification_enabled"] as? Boolean ?: true
            
            setLoading(false)
            Timber.d("Configuração carregada")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao carregar configuração")
            setError("Erro ao carregar configuração: ${e.message}")
            setLoading(false)
        }
    }

    suspend fun saveConfiguration(
        openAIKey: String,
        azureClientId: String,
        azureClientSecret: String,
        autoArchiveDays: Int
    ) {
        try {
            setLoading(true)
            
            // Validar entradas
            if (openAIKey.isBlank()) {
                setError("Chave da API OpenAI é obrigatória")
                setLoading(false)
                return
            }
            
            if (azureClientId.isBlank()) {
                setError("Client ID do Azure é obrigatório")
                setLoading(false)
                return
            }
            
            if (autoArchiveDays < 1 || autoArchiveDays > 365) {
                setError("Dias para auto-arquivamento deve estar entre 1 e 365")
                setLoading(false)
                return
            }

            // Salvar configurações de API (criptografadas)
            configurationManager.setOpenAIApiKey(openAIKey)
            configurationManager.setAzureClientId(azureClientId)
            
            if (azureClientSecret.isNotBlank()) {
                configurationManager.setAzureClientSecret(azureClientSecret)
            }

            // Salvar configurações gerais
            configurationManager.setSpeechRate(tempSpeechRate)
            configurationManager.setSpeechPitch(tempSpeechPitch)
            configurationManager.setLanguage(tempLanguage)
            configurationManager.setVoiceFeedbackEnabled(tempVoiceFeedbackEnabled)
            configurationManager.setHandsFreeMode(tempHandsFreeModeEnabled)
            configurationManager.setNotificationEnabled(tempNotificationsEnabled)
            configurationManager.setAutoArchiveDays(autoArchiveDays)
            
            // Marcar primeira configuração como concluída
            configurationManager.setFirstSetupCompleted(true)

            _configurationSaved.value = true
            setLoading(false)
            Timber.d("Configuração salva com sucesso")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao salvar configuração")
            setError("Erro ao salvar configuração: ${e.message}")
            setLoading(false)
        }
    }

    suspend fun testConnection(openAIKey: String, azureClientId: String) {
        try {
            setLoading(true)
            
            // Simular teste de conexão
            // TODO: Implementar teste real das APIs
            kotlinx.coroutines.delay(2000) // Simular delay de rede
            
            val isValid = openAIKey.startsWith("sk-") && azureClientId.isNotBlank()
            _connectionTestResult.value = isValid
            
            if (isValid) {
                Timber.d("Teste de conexão bem-sucedido")
            } else {
                Timber.w("Teste de conexão falhou")
            }
            
            setLoading(false)
        } catch (e: Exception) {
            Timber.e(e, "Erro no teste de conexão")
            setError("Erro no teste de conexão: ${e.message}")
            _connectionTestResult.value = false
            setLoading(false)
        }
    }

    fun isFirstSetupCompleted(): Boolean {
        return configurationManager.isFirstSetupCompleted()
    }

    // Métodos para configurações temporárias (antes de salvar)

    fun setSpeechRate(rate: Float) {
        tempSpeechRate = rate.coerceIn(0.1f, 3.0f)
        Timber.d("Velocidade da fala temporária: $tempSpeechRate")
    }

    fun setSpeechPitch(pitch: Float) {
        tempSpeechPitch = pitch.coerceIn(0.1f, 2.0f)
        Timber.d("Tom da voz temporário: $tempSpeechPitch")
    }

    fun setLanguage(language: String) {
        tempLanguage = language
        Timber.d("Idioma temporário: $tempLanguage")
    }

    fun setVoiceFeedbackEnabled(enabled: Boolean) {
        tempVoiceFeedbackEnabled = enabled
        Timber.d("Feedback de voz temporário: $tempVoiceFeedbackEnabled")
    }

    fun setHandsFreeModeEnabled(enabled: Boolean) {
        tempHandsFreeModeEnabled = enabled
        Timber.d("Modo hands-free temporário: $tempHandsFreeModeEnabled")
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        tempNotificationsEnabled = enabled
        Timber.d("Notificações temporárias: $tempNotificationsEnabled")
    }

    suspend fun clearAllConfiguration() {
        try {
            setLoading(true)
            configurationManager.clearAllConfiguration()
            
            // Resetar variáveis temporárias
            tempSpeechRate = 1.0f
            tempSpeechPitch = 1.0f
            tempLanguage = "pt-BR"
            tempVoiceFeedbackEnabled = true
            tempHandsFreeModeEnabled = false
            tempNotificationsEnabled = true
            
            setLoading(false)
            Timber.d("Todas as configurações foram limpas")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao limpar configurações")
            setError("Erro ao limpar configurações: ${e.message}")
            setLoading(false)
        }
    }

    fun getAvailableLanguages(): List<Pair<String, String>> {
        return listOf(
            "pt-BR" to "Português (Brasil)",
            "pt-PT" to "Português (Portugal)",
            "en-US" to "English (US)",
            "es-ES" to "Español (España)"
        )
    }

    fun getCurrentConfiguration(): Map<String, Any> {
        return mapOf(
            "speech_rate" to tempSpeechRate,
            "speech_pitch" to tempSpeechPitch,
            "language" to tempLanguage,
            "voice_feedback_enabled" to tempVoiceFeedbackEnabled,
            "hands_free_mode" to tempHandsFreeModeEnabled,
            "notification_enabled" to tempNotificationsEnabled
        )
    }

    fun validateConfiguration(
        openAIKey: String,
        azureClientId: String,
        autoArchiveDays: String
    ): String? {
        return when {
            openAIKey.isBlank() -> "Chave da API OpenAI é obrigatória"
            !openAIKey.startsWith("sk-") -> "Chave da API OpenAI deve começar com 'sk-'"
            azureClientId.isBlank() -> "Client ID do Azure é obrigatório"
            azureClientId.length < 10 -> "Client ID do Azure parece inválido"
            autoArchiveDays.isBlank() -> "Dias para auto-arquivamento é obrigatório"
            autoArchiveDays.toIntOrNull() == null -> "Dias para auto-arquivamento deve ser um número"
            (autoArchiveDays.toIntOrNull() ?: 0) < 1 -> "Dias para auto-arquivamento deve ser pelo menos 1"
            (autoArchiveDays.toIntOrNull() ?: 0) > 365 -> "Dias para auto-arquivamento não pode ser maior que 365"
            else -> null
        }
    }
}

