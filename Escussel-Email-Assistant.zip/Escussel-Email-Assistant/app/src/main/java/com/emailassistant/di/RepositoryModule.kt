package com.emailassistant.di

import com.emailassistant.data.repository.AIAnalysisRepository
import com.emailassistant.data.repository.EmailRepository
import com.emailassistant.data.repository.SpeechRepository
import com.emailassistant.data.repository.impl.AIAnalysisRepositoryImpl
import com.emailassistant.data.repository.impl.EmailRepositoryImpl
import com.emailassistant.data.repository.impl.SpeechRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Módulo de injeção de dependência para repositórios
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindEmailRepository(
        emailRepositoryImpl: EmailRepositoryImpl
    ): EmailRepository

    @Binds
    @Singleton
    abstract fun bindSpeechRepository(
        speechRepositoryImpl: SpeechRepositoryImpl
    ): SpeechRepository

    @Binds
    @Singleton
    abstract fun bindAIAnalysisRepository(
        aiAnalysisRepositoryImpl: AIAnalysisRepositoryImpl
    ): AIAnalysisRepository
}

