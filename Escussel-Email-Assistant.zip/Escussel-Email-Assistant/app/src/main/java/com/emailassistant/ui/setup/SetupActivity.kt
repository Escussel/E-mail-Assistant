package com.emailassistant.ui.setup

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.emailassistant.databinding.ActivitySetupBinding
import com.emailassistant.ui.auth.AuthActivity
import com.emailassistant.ui.main.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Atividade de configuração inicial do aplicativo
 */
@AndroidEntryPoint
class SetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupBinding
    private val viewModel: SetupViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()
        setupClickListeners()
        loadCurrentConfiguration()
    }

    private fun setupObservers() {
        // Observar estado de carregamento
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }
            
            // Desabilitar botões durante carregamento
            binding.btnSaveConfiguration.isEnabled = !isLoading
            binding.btnTestConnection.isEnabled = !isLoading
        }

        // Observar mensagens de erro
        viewModel.errorMessage.observe(this) { error ->
            if (error.isNotEmpty()) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        }

        // Observar sucesso na configuração
        viewModel.configurationSaved.observe(this) { saved ->
            if (saved) {
                Toast.makeText(this, "Configuração salva com sucesso!", Toast.LENGTH_SHORT).show()
                
                // Se é a primeira configuração, ir para autenticação
                if (!viewModel.isFirstSetupCompleted()) {
                    startActivity(Intent(this, AuthActivity::class.java))
                    finish()
                } else {
                    // Voltar para a tela principal
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            }
        }

        // Observar teste de conexão
        viewModel.connectionTestResult.observe(this) { result ->
            val message = if (result) {
                "Conexão testada com sucesso!"
            } else {
                "Falha no teste de conexão. Verifique as configurações."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }

        // Observar configuração carregada
        viewModel.configurationLoaded.observe(this) { config ->
            updateUIWithConfiguration(config)
        }
    }

    private fun setupClickListeners() {
        // Botão salvar configuração
        binding.btnSaveConfiguration.setOnClickListener {
            saveConfiguration()
        }

        // Botão testar conexão
        binding.btnTestConnection.setOnClickListener {
            testConnection()
        }

        // Botão voltar
        binding.btnBack.setOnClickListener {
            finish()
        }

        // Botão pular configuração (apenas se não for primeira vez)
        binding.btnSkip.setOnClickListener {
            if (viewModel.isFirstSetupCompleted()) {
                finish()
            } else {
                Toast.makeText(this, "Configuração inicial é obrigatória", Toast.LENGTH_SHORT).show()
            }
        }

        // Switch de feedback de voz
        binding.switchVoiceFeedback.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setVoiceFeedbackEnabled(isChecked)
        }

        // Switch de modo hands-free
        binding.switchHandsFree.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setHandsFreeModeEnabled(isChecked)
        }

        // Switch de notificações
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            viewModel.setNotificationsEnabled(isChecked)
        }

        // Slider de velocidade da fala
        binding.sliderSpeechRate.addOnChangeListener { _, value, _ ->
            viewModel.setSpeechRate(value)
            binding.tvSpeechRateValue.text = String.format("%.1fx", value)
        }

        // Slider de tom da voz
        binding.sliderSpeechPitch.addOnChangeListener { _, value, _ ->
            viewModel.setSpeechPitch(value)
            binding.tvSpeechPitchValue.text = String.format("%.1fx", value)
        }

        // Spinner de idioma
        binding.spinnerLanguage.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                val languages = resources.getStringArray(com.emailassistant.R.array.language_codes)
                if (position < languages.size) {
                    viewModel.setLanguage(languages[position])
                }
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
    }

    private fun loadCurrentConfiguration() {
        lifecycleScope.launch {
            viewModel.loadCurrentConfiguration()
        }
    }

    private fun saveConfiguration() {
        lifecycleScope.launch {
            val openAIKey = binding.etOpenaiApiKey.text.toString().trim()
            val azureClientId = binding.etAzureClientId.text.toString().trim()
            val azureClientSecret = binding.etAzureClientSecret.text.toString().trim()
            val autoArchiveDays = binding.etAutoArchiveDays.text.toString().toIntOrNull() ?: 30

            if (openAIKey.isEmpty()) {
                Toast.makeText(this@SetupActivity, "Chave da API OpenAI é obrigatória", Toast.LENGTH_SHORT).show()
                return@launch
            }

            if (azureClientId.isEmpty()) {
                Toast.makeText(this@SetupActivity, "Client ID do Azure é obrigatório", Toast.LENGTH_SHORT).show()
                return@launch
            }

            viewModel.saveConfiguration(
                openAIKey = openAIKey,
                azureClientId = azureClientId,
                azureClientSecret = azureClientSecret,
                autoArchiveDays = autoArchiveDays
            )
        }
    }

    private fun testConnection() {
        lifecycleScope.launch {
            val openAIKey = binding.etOpenaiApiKey.text.toString().trim()
            val azureClientId = binding.etAzureClientId.text.toString().trim()

            if (openAIKey.isEmpty() || azureClientId.isEmpty()) {
                Toast.makeText(this@SetupActivity, "Preencha as configurações antes de testar", Toast.LENGTH_SHORT).show()
                return@launch
            }

            viewModel.testConnection(openAIKey, azureClientId)
        }
    }

    private fun updateUIWithConfiguration(config: Map<String, Any>) {
        try {
            // Configurações de API (serão carregadas separadamente por segurança)
            binding.etAutoArchiveDays.setText((config["auto_archive_days"] as? Int ?: 30).toString())

            // Configurações de voz
            val speechRate = config["speech_rate"] as? Float ?: 1.0f
            val speechPitch = config["speech_pitch"] as? Float ?: 1.0f
            val language = config["language"] as? String ?: "pt-BR"

            binding.sliderSpeechRate.value = speechRate
            binding.tvSpeechRateValue.text = String.format("%.1fx", speechRate)

            binding.sliderSpeechPitch.value = speechPitch
            binding.tvSpeechPitchValue.text = String.format("%.1fx", speechPitch)

            // Configurar spinner de idioma
            val languages = resources.getStringArray(com.emailassistant.R.array.language_codes)
            val languageIndex = languages.indexOf(language)
            if (languageIndex >= 0) {
                binding.spinnerLanguage.setSelection(languageIndex)
            }

            // Configurações de comportamento
            binding.switchVoiceFeedback.isChecked = config["voice_feedback_enabled"] as? Boolean ?: true
            binding.switchHandsFree.isChecked = config["hands_free_mode"] as? Boolean ?: false
            binding.switchNotifications.isChecked = config["notification_enabled"] as? Boolean ?: true

            // Verificar se é primeira configuração
            val isFirstSetup = !(config["first_setup_completed"] as? Boolean ?: false)
            binding.btnSkip.visibility = if (isFirstSetup) {
                android.view.View.GONE
            } else {
                android.view.View.VISIBLE
            }

            Timber.d("Configuração carregada na UI")
        } catch (e: Exception) {
            Timber.e(e, "Erro ao atualizar UI com configuração")
            Toast.makeText(this, "Erro ao carregar configuração", Toast.LENGTH_SHORT).show()
        }
    }
}

