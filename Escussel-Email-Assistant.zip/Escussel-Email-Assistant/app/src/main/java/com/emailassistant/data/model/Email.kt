package com.emailassistant.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.Date

/**
 * Modelo de dados para representar um e-mail
 */
@Parcelize
data class Email(
    val id: String,
    val subject: String,
    val sender: EmailAddress,
    val recipients: List<EmailAddress>,
    val body: String,
    val bodyPreview: String,
    val receivedDateTime: Date,
    val isRead: Boolean,
    val importance: EmailImportance,
    val hasAttachments: Boolean,
    val conversationId: String,
    val categories: List<String> = emptyList(),
    val flag: EmailFlag? = null
) : Parcelable

@Parcelize
data class EmailAddress(
    val name: String,
    val address: String
) : Parcelable

@Parcelize
enum class EmailImportance : Parcelable {
    LOW, NORMAL, HIGH
}

@Parcelize
data class EmailFlag(
    val status: FlagStatus,
    val dueDateTime: Date? = null
) : Parcelable

@Parcelize
enum class FlagStatus : Parcelable {
    NOT_FLAGGED, COMPLETE, FLAGGED
}

